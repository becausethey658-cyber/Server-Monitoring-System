# -*- coding: utf-8 -*-
"""启动入口：内置依赖路径，便于在演示环境中直接运行。"""
import os
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ROOT, "vendor"))
sys.path.insert(0, os.path.join(ROOT, "server_inspection"))

from app import main  # noqa: E402

if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""共享列网格的数据表，保证表头与每一行的列宽严格对齐。"""
from __future__ import annotations

import customtkinter as ctk

from components import Pill
from theme import COLORS, F, health_color, level_palette, status_palette


class DataTable(ctk.CTkFrame):
    def __init__(self, master, columns, rows, row_height=44, on_row_click=None, footer=None,
                 footer_right="", striped=False, header_height=36):
        super().__init__(master, fg_color="transparent")
        self.columns = columns
        self.rows = rows
        self.on_row_click = on_row_click
        self.row_cells = []
        self.grid_columnconfigure(0, weight=1)

        for i, col in enumerate(columns):
            self.grid_columnconfigure(i, weight=col.get("width", 100), minsize=col.get("minwidth", 38))
        self.grid_rowconfigure(0, minsize=header_height)

        for i, col in enumerate(columns):
            head_cell = ctk.CTkFrame(self, fg_color=COLORS["surface_alt"], corner_radius=0,
                                     height=header_height)
            head_cell.grid(row=0, column=i, sticky="nsew")
            head_cell.grid_propagate(False)
            ctk.CTkLabel(head_cell, text=col["title"], font=F(10, "bold"), text_color=COLORS["text_muted"],
                         anchor=col.get("anchor", "w"), fg_color=COLORS["surface_alt"]).pack(
                fill="both", expand=True, padx=(13 if i == 0 else 7, 7))

        for r, row in enumerate(rows):
            row_idx = 1 + r * 2
            self.grid_rowconfigure(row_idx, minsize=row_height)
            cells = []
            row_widgets = []
            for i, col in enumerate(columns):
                cell = ctk.CTkFrame(self, fg_color=COLORS["surface"], corner_radius=0)
                cell.grid(row=row_idx, column=i, sticky="nsew")
                inner = ctk.CTkFrame(cell, fg_color="transparent")
                inner.pack(fill="both", expand=True, padx=(13 if i == 0 else 7, 7), pady=1)
                inner.grid_rowconfigure(0, weight=1)
                inner.grid_columnconfigure(0, weight=1)
                widgets = self._render(inner, col, row)
                allw = [cell, inner] + widgets
                for w in allw:
                    if self.on_row_click:
                        w.bind("<Button-1>", lambda e, rr=row: self.on_row_click(rr))
                    w.bind("<Enter>", lambda e, cs=cells: self._hover(cs, True))
                    w.bind("<Leave>", lambda e, cs=cells: self._hover(cs, False))
                row_widgets.extend(allw)
                cells.append(cell)
            self.row_cells.append(cells)
            sep = ctk.CTkFrame(self, height=1, fg_color=COLORS["border"], corner_radius=0)
            sep.grid(row=row_idx + 1, column=0, columnspan=len(columns), sticky="ew")

        if footer:
            frow = 1 + len(rows) * 2
            foot = ctk.CTkFrame(self, fg_color="transparent", height=32)
            foot.grid(row=frow, column=0, columnspan=len(columns), sticky="ew", pady=(7, 0))
            foot.grid_columnconfigure(0, weight=1)
            ctk.CTkLabel(foot, text=footer, font=F(9.7), text_color=COLORS["text_muted"]).grid(
                row=0, column=0, sticky="w")
            if footer_right:
                ctk.CTkLabel(foot, text=footer_right, font=F(9.7), text_color=COLORS["text_muted"]).grid(
                    row=0, column=1, sticky="e")

    def _hover(self, cells, on):
        color = "#F7FAFF" if on else COLORS["surface"]
        for cell in cells:
            try:
                cell.configure(fg_color=color)
            except Exception:
                pass

    def _render(self, inner, col, row):
        typ = col.get("type", "text")
        value = row.get(col.get("key"), "")
        anchor = col.get("anchor", "w")
        sticky = "ew" if anchor == "center" else "w"

        if typ == "stack":
            box = ctk.CTkFrame(inner, fg_color="transparent")
            box.grid(row=0, column=0, sticky="w")
            title = ctk.CTkLabel(box, text=str(value), font=F(col.get("size", 10.5), "bold"),
                                 text_color=col.get("color", COLORS["text"]), anchor=anchor, height=17)
            title.pack(anchor=anchor)
            sub = ctk.CTkLabel(box, text=str(row.get(col.get("sub", ""), "")), font=F(col.get("sub_size", 8.6)),
                               text_color=COLORS["text_muted"], anchor=anchor, height=14)
            sub.pack(anchor=anchor, pady=(0, 0))
            return [box, title, sub]

        if typ in ("status", "level", "pill"):
            if typ == "status":
                fg, bg = status_palette(value)
            elif typ == "level":
                fg, bg = level_palette(value)
            else:
                fg, bg = col.get("fg", COLORS["primary"]), col.get("bg", COLORS["primary_soft"])
            pill = Pill(inner, value, fg, bg)
            pill.grid(row=0, column=0, sticky=sticky)
            return [pill]

        if typ == "health":
            fg = health_color(int(value))
            box = ctk.CTkFrame(inner, fg_color="transparent")
            box.grid(row=0, column=0, sticky="w")
            ctk.CTkFrame(box, width=6, height=6, corner_radius=3, fg_color=fg).pack(side="left", padx=(0, 6))
            lab = ctk.CTkLabel(box, text=str(value), font=F(10.6, "bold"), text_color=fg, height=22)
            lab.pack(side="left")
            return [box, lab]

        if typ == "progress":
            box = ctk.CTkFrame(inner, fg_color="transparent")
            box.grid(row=0, column=0, sticky="ew")
            bar = ctk.CTkProgressBar(box, height=5, corner_radius=3, fg_color=COLORS["track"],
                                     progress_color=COLORS["primary"] if int(value) < 100 else COLORS["success"])
            bar.pack(side="left", fill="x", expand=True)
            bar.set(int(value) / 100)
            lab = ctk.CTkLabel(box, text=f"{int(value)}%", font=F(9.3, "bold"),
                               text_color=COLORS["text_secondary"], width=34)
            lab.pack(side="left", padx=(6, 0))
            if self.on_row_click:
                bar.bind("<Button-1>", lambda e, r=row: self.on_row_click(r))
            return [box, bar, lab]

        if typ == "switch":
            sw = ctk.CTkSwitch(inner, text="", width=40, height=20, switch_width=38, switch_height=20,
                               progress_color=COLORS["primary"], fg_color=COLORS["border_strong"],
                               button_color="#FFFFFF", button_hover_color="#F5F8FF",
                               command=lambda r=row: col.get("command", lambda x: None)(r))
            sw.grid(row=0, column=0, sticky="w")
            (sw.select if value == "启用" else sw.deselect)()
            return [sw]

        if typ == "actions":
            box = ctk.CTkFrame(inner, fg_color="transparent")
            box.grid(row=0, column=0, sticky="w")
            for txt, act_key in col.get("actions", [("查看", "view")]):
                color = COLORS["danger"] if act_key == "retry" else COLORS["primary"]
                b = ctk.CTkButton(box, text=txt, width=36, height=23, fg_color="transparent",
                                  hover_color=COLORS["primary_soft"], text_color=color, font=F(9.7, "bold"),
                                  command=lambda r=row, a=act_key: col.get("command", lambda x, y: None)(r, a))
                b.pack(side="left", padx=(0, 2))
            return [box]

        if typ == "mono":
            lab = ctk.CTkLabel(inner, text=str(value), font=("Consolas", col.get("size", 9.5)),
                               text_color=col.get("color", COLORS["text_secondary"]), anchor=anchor, height=22)
        else:
            lab = ctk.CTkLabel(inner, text=str(value), font=F(col.get("size", 10.3), col.get("weight", "normal")),
                               text_color=col.get("color", COLORS["text_secondary"]), anchor=anchor,
                               justify="left", height=22)
        lab.grid(row=0, column=0, sticky=sticky)
        return [lab]

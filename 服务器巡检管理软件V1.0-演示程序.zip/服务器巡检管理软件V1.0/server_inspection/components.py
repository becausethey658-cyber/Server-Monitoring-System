# -*- coding: utf-8 -*-
"""可复用界面组件：卡片、表头、数据表、状态胶囊、弹窗与提示。"""
from __future__ import annotations

from typing import Callable

import customtkinter as ctk

from icons import icon
from theme import COLORS, F, health_color, level_palette, status_palette


class Card(ctk.CTkFrame):
    def __init__(self, master, padding=16, **kwargs):
        kwargs.setdefault("fg_color", COLORS["surface"])
        kwargs.setdefault("corner_radius", 12)
        kwargs.setdefault("border_width", 1)
        kwargs.setdefault("border_color", COLORS["border"])
        super().__init__(master, **kwargs)
        self.body = ctk.CTkFrame(self, fg_color="transparent")
        self.body.pack(fill="both", expand=True, padx=padding, pady=padding)


class Pill(ctk.CTkLabel):
    def __init__(self, master, text, fg=None, bg=None, size=10, bold=True, **kwargs):
        if fg is None or bg is None:
            fg, bg = status_palette(text)
        super().__init__(master, text=f" {text} ", fg_color=bg, text_color=fg, corner_radius=9,
                         height=21, font=F(size, "bold" if bold else "normal"), **kwargs)


def action_button(master, text, command=None, kind="primary", icon_name=None, width=92, height=34):
    palette = {
        "primary": (COLORS["primary"], "#FFFFFF", COLORS["primary_hover"], None),
        "secondary": (COLORS["surface"], COLORS["text_secondary"], COLORS["surface_alt"], COLORS["border_strong"]),
        "ghost": ("transparent", COLORS["text_secondary"], COLORS["surface_alt"], None),
        "danger": (COLORS["danger_soft"], COLORS["danger"], "#FADADA", None),
    }
    fg, txt, hover, border = palette.get(kind, palette["secondary"])
    return ctk.CTkButton(
        master, text=text, command=command,
        image=icon(icon_name, txt if kind != "primary" else "#FFFFFF", 16) if icon_name else None,
        compound="left", fg_color=fg, hover_color=hover, text_color=txt,
        border_width=1 if border else 0, border_color=border or COLORS["border"],
        corner_radius=8, height=height, width=width, font=F(11.5, "bold"),
    )


def text_button(master, text, command=None, color=None, size=10.5):
    return ctk.CTkButton(master, text=text, command=command, fg_color="transparent",
                         hover_color=COLORS["primary_soft"], text_color=color or COLORS["primary"],
                         font=F(size, "bold"), height=24, width=40, corner_radius=6)


class PageHeader(ctk.CTkFrame):
    def __init__(self, master, title, subtitle="", actions=None):
        super().__init__(master, fg_color="transparent", height=48)
        self.grid_columnconfigure(0, weight=1)
        self.grid_propagate(False)
        left = ctk.CTkFrame(self, fg_color="transparent")
        left.grid(row=0, column=0, sticky="w")
        ctk.CTkLabel(left, text=title, font=F(22, "bold"), text_color=COLORS["text"], anchor="w").pack(anchor="w")
        if subtitle:
            ctk.CTkLabel(left, text=subtitle, font=F(11), text_color=COLORS["text_muted"], anchor="w").pack(
                anchor="w", pady=(2, 0))
        if actions:
            right = ctk.CTkFrame(self, fg_color="transparent")
            right.grid(row=0, column=1, sticky="e")
            for item in actions:
                btn = action_button(right, item["text"], item.get("command"), item.get("kind", "secondary"),
                                    item.get("icon"), item.get("width", 96))
                btn.pack(side="left", padx=(8, 0))


class SearchBox(ctk.CTkFrame):
    def __init__(self, master, placeholder="搜索", width=250, command=None, height=36):
        super().__init__(master, fg_color=COLORS["surface"], border_width=1, border_color=COLORS["border_strong"],
                         corner_radius=8, height=height, width=width)
        self.grid_propagate(False)
        self.grid_columnconfigure(1, weight=1)
        self.command = command
        ctk.CTkLabel(self, text="", image=icon("search", COLORS["text_muted"], 16), width=20).grid(
            row=0, column=0, padx=(10, 4), sticky="w")
        self.entry = ctk.CTkEntry(self, placeholder_text=placeholder, border_width=0, fg_color="transparent",
                                  text_color=COLORS["text"], placeholder_text_color=COLORS["text_muted"],
                                  font=F(11), height=30)
        self.entry.grid(row=0, column=1, sticky="ew", padx=(0, 8))
        self.entry.bind("<Return>", lambda e: self.command(self.entry.get()) if self.command else None)


class FilterChip(ctk.CTkButton):
    def __init__(self, master, text, active=False, command=None, width=76, count=None):
        label = f"{text}  {count}" if count is not None else text
        super().__init__(master, text=label, command=command, height=30, width=width, corner_radius=7,
                         fg_color=COLORS["primary"] if active else "transparent",
                         hover_color=COLORS["primary_soft"] if not active else COLORS["primary_hover"],
                         text_color="#FFFFFF" if active else COLORS["text_secondary"],
                         font=F(10.5, "bold"))


class StatCard(Card):
    def __init__(self, master, title, value, note, icon_name="server", tone="blue", accent=None,
                 suffix="", progress=None, **kwargs):
        super().__init__(master, padding=12, **kwargs)
        tones = {
            "blue": ("#EAF1FF", COLORS["primary"]),
            "green": ("#E9F8EF", COLORS["success"]),
            "amber": ("#FFF5E5", COLORS["warning"]),
            "red": ("#FDECEC", COLORS["danger"]),
            "violet": ("#F1EBFF", COLORS["violet"]),
            "cyan": ("#E7F8FB", COLORS["info"]),
        }
        soft, solid = tones.get(tone, tones["blue"])
        accent = accent or solid
        top = ctk.CTkFrame(self.body, fg_color="transparent")
        top.pack(fill="x")
        ctk.CTkLabel(top, text=title, font=F(10.2), text_color=COLORS["text_secondary"], height=16).pack(side="left")
        badge = ctk.CTkFrame(top, width=28, height=28, corner_radius=8, fg_color=soft)
        badge.pack(side="right")
        badge.pack_propagate(False)
        ctk.CTkLabel(badge, text="", image=icon(icon_name, solid, 16)).pack(expand=True)
        line = ctk.CTkFrame(self.body, fg_color="transparent")
        line.pack(fill="x", pady=(4, 0))
        ctk.CTkLabel(line, text=str(value), font=F(23, "bold"), text_color=COLORS["text"], height=34).pack(side="left")
        if suffix:
            ctk.CTkLabel(line, text=suffix, font=F(9.5, "bold"), text_color=COLORS["text_muted"], height=18).pack(
                side="left", padx=(3, 0), pady=(7, 0))
        ctk.CTkLabel(self.body, text=note, font=F(8.9), text_color=accent, anchor="w", height=15).pack(
            fill="x", pady=(1, 0))
        if progress is not None:
            bar = ctk.CTkProgressBar(self.body, height=4, corner_radius=2, fg_color=COLORS["track"],
                                     progress_color=accent)
            bar.pack(fill="x", pady=(4, 2))
            bar.set(progress)


class TabBar(ctk.CTkFrame):
    def __init__(self, master, tabs, active=0, command=None):
        super().__init__(master, fg_color="transparent", height=34)
        self.tabs = tabs
        self.command = command
        self.buttons = []
        for i, item in enumerate(tabs):
            text, count = (item if isinstance(item, tuple) else (item, None))
            label = f"{text}  {count}" if count is not None else text
            b = ctk.CTkButton(self, text=label, height=30, width=82, corner_radius=7,
                              fg_color=COLORS["primary"] if i == active else "transparent",
                              hover_color=COLORS["primary_soft"] if i != active else COLORS["primary_hover"],
                              text_color="#FFFFFF" if i == active else COLORS["text_secondary"],
                              font=F(10.5, "bold"),
                              command=lambda idx=i: self.select(idx))
            b.pack(side="left", padx=(0, 5))
            self.buttons.append(b)

    def select(self, idx):
        for i, b in enumerate(self.buttons):
            b.configure(fg_color=COLORS["primary"] if i == idx else "transparent",
                        text_color="#FFFFFF" if i == idx else COLORS["text_secondary"],
                        hover_color=COLORS["primary_hover"] if i == idx else COLORS["primary_soft"])
        if self.command:
            self.command(idx)


class Toast(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master, fg_color=COLORS["surface"], border_width=1, border_color="#BBF7D0",
                         corner_radius=10, height=44)
        self.grid_propagate(False)
        self.grid_columnconfigure(1, weight=1)
        self.icon_label = ctk.CTkLabel(self, text="", image=icon("check", COLORS["success"], 18), width=28)
        self.icon_label.grid(row=0, column=0, padx=(12, 0))
        self.label = ctk.CTkLabel(self, text="", font=F(10.5), text_color=COLORS["text"])
        self.label.grid(row=0, column=1, padx=(4, 14), sticky="w")
        self._job = None

    def show(self, text, tone="success"):
        color = COLORS["success"] if tone == "success" else COLORS["warning"] if tone == "warning" else COLORS["danger"]
        self.icon_label.configure(image=icon("check" if tone == "success" else "issue", color, 18))
        self.label.configure(text=text)
        self.configure(border_color="#BBF7D0" if tone == "success" else "#FDE68A" if tone == "warning" else "#FECACA")
        self.place(relx=1.0, rely=1.0, x=-22, y=-20, anchor="se")
        self.lift()
        if self._job:
            self.after_cancel(self._job)
        self._job = self.after(3200, self.place_forget)


class BaseDialog(ctk.CTkToplevel):
    def __init__(self, master, title, width=620, height=460, subtitle=""):
        super().__init__(master, fg_color=COLORS["surface"])
        self.title(title)
        self.resizable(False, False)
        self.transient(master)
        self.grab_set()
        self._dialog_width, self._dialog_height = width, height
        self.geometry(f"{width}x{height}")
        self.update_idletasks()
        try:
            sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
            scale = self._get_window_scaling()
            w, h = int(width * scale), int(height * scale)
            self.geometry(f"+{max(0, (sw - w) // 2)}+{max(0, (sh - h) // 2)}")
        except Exception:
            pass
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)
        head = ctk.CTkFrame(self, fg_color="transparent", height=68)
        head.grid(row=0, column=0, sticky="ew", padx=24, pady=(18, 0))
        head.grid_propagate(False)
        ctk.CTkLabel(head, text=title, font=F(18, "bold"), text_color=COLORS["text"]).pack(side="left",
                                                                                          anchor="w")
        if subtitle:
            ctk.CTkLabel(head, text=subtitle, font=F(10.5), text_color=COLORS["text_muted"]).pack(
                side="left", anchor="w", padx=(12, 0), pady=(5, 0))
        ctk.CTkButton(head, text="", image=icon("close", COLORS["text_muted"], 17), width=30, height=30,
                      fg_color="transparent", hover_color=COLORS["surface_alt"], command=self.destroy).pack(
            side="right")
        ctk.CTkFrame(self, height=1, fg_color=COLORS["border"]).grid(row=0, column=0, sticky="sew", padx=1)
        self.content = ctk.CTkFrame(self, fg_color="transparent")
        self.content.grid(row=1, column=0, sticky="nsew", padx=24, pady=(16, 18))
        self.after(80, self.focus_force)

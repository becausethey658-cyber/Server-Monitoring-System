# -*- coding: utf-8 -*-
"""服务器巡检管理软件 V1.0 — 桌面端交互原型。"""
from __future__ import annotations

import copy
import os
import sys
import time
import tkinter as tk
from datetime import datetime

import customtkinter as ctk
from PIL import ImageGrab

import charts
from components import (BaseDialog, Card, FilterChip, PageHeader, Pill, SearchBox,
                        StatCard, TabBar, Toast, action_button, text_button)
from data import (ALERTS, AUDIT_LOGS, BRAND, CHECK_ITEMS, ISSUE_TIMELINE, ISSUES, METRICS, NAV,
                  PLANS, REPORT_HISTORY, SERVERS, TASK_LOGS, TASK_SERVERS, TASKS, TEMPLATES,
                  TODO_ITEMS)
from icons import icon, logo_image
from table import DataTable
from theme import COLORS, F, health_color, level_palette, status_palette

APP_TITLE = f"{BRAND['product']} {BRAND['version']}"
DATA_DATE = "2026-10-28 周三"


def _clear(frame):
    for child in frame.winfo_children():
        child.destroy()


def _label(parent, text, size=11, color=None, weight="normal", **kwargs):
    return ctk.CTkLabel(parent, text=text, font=F(size, weight), text_color=color or COLORS["text"], **kwargs)


class App(ctk.CTk):
    def __init__(self, capture_mode=False):
        super().__init__(fg_color=COLORS["bg"])
        self.capture_mode = capture_mode
        self._image_refs = []
        self._active_nav = "dashboard"
        self._current_page = None
        self._live_job = None

        ctk.set_appearance_mode("light")
        self.title(APP_TITLE)
        self.geometry("1280x800+30+30")
        self.minsize(1180, 720)
        self.configure(fg_color=COLORS["bg"])
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        self.sidebar = ctk.CTkFrame(self, width=210, corner_radius=0, fg_color=COLORS["sidebar"])
        self.sidebar.grid(row=0, column=0, sticky="nsw")
        self.sidebar.grid_propagate(False)
        self._build_sidebar()

        self.main = ctk.CTkFrame(self, fg_color=COLORS["bg"], corner_radius=0)
        self.main.grid(row=0, column=1, sticky="nsew")
        self.main.grid_rowconfigure(1, weight=1)
        self.main.grid_columnconfigure(0, weight=1)
        self._build_topbar()

        self.page_host = ctk.CTkFrame(self.main, fg_color=COLORS["bg"], corner_radius=0)
        self.page_host.grid(row=1, column=0, sticky="nsew")
        self.page_host.grid_rowconfigure(0, weight=1)
        self.page_host.grid_columnconfigure(0, weight=1)

        self.pages = {}
        self.detail_frames = {}
        self._build_all_pages()
        self.toast = Toast(self)

        self.show_page("dashboard")
        if capture_mode:
            self.attributes("-topmost", True)
            self.after(800, self._prepare_capture_position)

    # ------------------------------------------------------------------ shell
    def _build_sidebar(self):
        brand = ctk.CTkFrame(self.sidebar, fg_color="transparent", height=78)
        brand.pack(fill="x", padx=13, pady=(16, 6))
        brand.pack_propagate(False)
        ctk.CTkLabel(brand, text="", image=logo_image(38), width=38).pack(side="left", padx=(2, 10))
        box = ctk.CTkFrame(brand, fg_color="transparent")
        box.pack(side="left", fill="y", pady=(8, 0))
        ctk.CTkLabel(box, text="巡检云台", font=F(16, "bold"), text_color="#F8FAFC",
                     anchor="w").pack(anchor="w")
        ctk.CTkLabel(box, text="S E R V E R   O P S", font=F(7.2, "bold"),
                     text_color="#5F7690", anchor="w").pack(anchor="w", pady=(1, 0))

        nav = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        nav.pack(fill="both", expand=True, padx=12, pady=(4, 0))
        groups = [
            ("概览", [("dashboard", "工作台", "dashboard")]),
            ("资产与配置", [("servers", "服务器资产", "server"), ("templates", "巡检模板", "template"),
                          ("plans", "巡检计划", "plan")]),
            ("巡检运营", [("tasks", "巡检任务", "task"), ("issues", "异常工单", "issue"),
                         ("reports", "报表中心", "report")]),
            ("系统", [("settings", "系统设置", "settings")]),
        ]
        self.nav_buttons = {}
        for group_name, items in groups:
            ctk.CTkLabel(nav, text=group_name, font=F(8.4, "bold"), text_color="#5F7690",
                         anchor="w").pack(fill="x", padx=11, pady=(10, 5))
            for key, label, icon_name in items:
                b = ctk.CTkButton(nav, text="   " + label, image=icon(icon_name, COLORS["sidebar_text"], 17),
                                  compound="left", anchor="w", height=36, width=186, corner_radius=7,
                                  fg_color="transparent", hover_color="#1A2B41",
                                  text_color=COLORS["sidebar_text"], font=F(11.2),
                                  command=lambda k=key: self.show_page(k))
                b.pack(fill="x", pady=1)
                self.nav_buttons[key] = (b, icon_name)

        bottom = ctk.CTkFrame(self.sidebar, fg_color="transparent")
        bottom.pack(fill="x", side="bottom", padx=12, pady=(8, 14))
        engine = ctk.CTkFrame(bottom, fg_color="#14243A", corner_radius=9, height=68)
        engine.pack(fill="x")
        engine.pack_propagate(False)
        top = ctk.CTkFrame(engine, fg_color="transparent")
        top.pack(fill="x", padx=11, pady=(9, 0))
        ctk.CTkFrame(top, width=6, height=6, corner_radius=3, fg_color="#34D399").pack(side="left",
                                                                                       padx=(0, 7))
        ctk.CTkLabel(top, text="巡检引擎运行正常", font=F(9.3, "bold"), text_color="#E6EEF8").pack(side="left")
        ctk.CTkLabel(engine, text="心跳 12 秒前  ·  执行队列 0", font=F(8.2), text_color="#7990A9",
                     anchor="w").pack(fill="x", padx=12, pady=(4, 0))
        ctk.CTkLabel(bottom, text=f"{BRAND['version']}  ·  演示环境", font=F(8.2),
                     text_color="#52677F").pack(anchor="w", padx=4, pady=(8, 0))

    def _build_topbar(self):
        bar = ctk.CTkFrame(self.main, fg_color=COLORS["surface"], corner_radius=0, height=61)
        bar.grid(row=0, column=0, sticky="ew")
        bar.grid_propagate(False)
        bar.grid_columnconfigure(1, weight=1)

        left = ctk.CTkFrame(bar, fg_color="transparent")
        left.grid(row=0, column=0, sticky="w", padx=(22, 0))
        ctk.CTkLabel(left, text="运维中心", font=F(10.5, "bold"), text_color=COLORS["text"]).pack(side="left")
        ctk.CTkLabel(left, text="/", font=F(10.5), text_color=COLORS["border_strong"]).pack(side="left",
                                                                                            padx=7)
        self.crumb = ctk.CTkLabel(left, text="工作台", font=F(10.5), text_color=COLORS["text_muted"])
        self.crumb.pack(side="left")

        search_wrap = ctk.CTkFrame(bar, fg_color="transparent")
        search_wrap.grid(row=0, column=1, sticky="w", padx=(22, 0))
        self.global_search = SearchBox(search_wrap, "搜索服务器、IP、任务编号…", width=278, height=34,
                                       command=self._global_search)
        self.global_search.pack()
        self._bind_ctrl_k()

        right = ctk.CTkFrame(bar, fg_color="transparent")
        right.grid(row=0, column=2, sticky="e", padx=(8, 18))
        live = ctk.CTkFrame(right, fg_color="transparent")
        live.pack(side="left", padx=(0, 13))
        ctk.CTkFrame(live, width=6, height=6, corner_radius=3, fg_color=COLORS["success"]).pack(side="left",
                                                                                                padx=(0, 5))
        ctk.CTkLabel(live, text="系统运行正常", font=F(9.2), text_color=COLORS["text_muted"]).pack(side="left")
        ctk.CTkLabel(right, text="2026-10-28 周三", font=F(9.2), text_color=COLORS["text_muted"]).pack(
            side="left", padx=(0, 12))
        ctk.CTkLabel(right, text=" 演示环境 ", font=F(8.6, "bold"), text_color="#B45309",
                     fg_color="#FFF5E5", corner_radius=8, height=20).pack(side="left", padx=(0, 8))
        bell = ctk.CTkButton(right, text="", image=icon("bell", COLORS["text_secondary"], 18), width=30,
                             height=30, fg_color="transparent", hover_color=COLORS["surface_alt"],
                             command=self._show_alerts)
        bell.pack(side="left", padx=(0, 4))
        ctk.CTkFrame(bell, width=7, height=7, corner_radius=4, fg_color=COLORS["danger"]).place(
            relx=0.72, rely=0.22, anchor="center")
        ctk.CTkFrame(right, width=1, height=24, fg_color=COLORS["border"]).pack(side="left", padx=(3, 12))
        avatar = ctk.CTkLabel(right, text="李", width=30, height=30, fg_color=COLORS["primary"],
                              corner_radius=15, text_color="#FFFFFF", font=F(11, "bold"))
        avatar.pack(side="left")
        user = ctk.CTkFrame(right, fg_color="transparent")
        user.pack(side="left", padx=(8, 0))
        ctk.CTkLabel(user, text="李明", font=F(9.8, "bold"), text_color=COLORS["text"],
                     anchor="w").pack(anchor="w")
        ctk.CTkLabel(user, text="运维管理员", font=F(8.2), text_color=COLORS["text_muted"],
                     anchor="w").pack(anchor="w")
        ctk.CTkLabel(right, text="", image=icon("chevron_down", COLORS["text_muted"], 14)).pack(
            side="left", padx=(6, 0))

        ctk.CTkFrame(self.main, height=1, fg_color=COLORS["border"]).place(relx=0, rely=0, relwidth=1,
                                                                           y=60)

    def _bind_ctrl_k(self):
        self.bind_all("<Control-k>", lambda e: self.global_search.entry.focus_set())
        self.bind_all("<Control-K>", lambda e: self.global_search.entry.focus_set())

    def _global_search(self, text):
        text = (text or "").strip()
        if not text:
            return
        hits = [s for s in SERVERS if text.lower() in (s["name"] + s["ip"] + s["group"]).lower()]
        if hits:
            self.show_page("servers")
            self.toast.show(f"找到 {len(hits)} 台匹配服务器，已在资产列表中展示", "success")
        else:
            self.toast.show(f"未找到与“{text}”相关的资产或任务", "warning")

    def _show_alerts(self):
        self.show_page("issues")
        self.toast.show("已定位到 4 条未读异常通知", "warning")

    def _prepare_capture_position(self):
        self.update_idletasks()
        try:
            self.geometry("+20+20")
        except Exception:
            pass

    def _on_close(self):
        if self._live_job:
            try:
                self.after_cancel(self._live_job)
            except Exception:
                pass
        self.destroy()

    def _activate_nav(self, key):
        self._active_nav = key
        for k, (button, icon_name) in self.nav_buttons.items():
            if k == key:
                button.configure(fg_color=COLORS["primary"], hover_color=COLORS["primary_hover"],
                                 text_color="#FFFFFF", image=icon(icon_name, "#FFFFFF", 17))
            else:
                button.configure(fg_color="transparent", hover_color="#1A2B41",
                                 text_color=COLORS["sidebar_text"],
                                 image=icon(icon_name, COLORS["sidebar_text"], 17))
        page_name = next((label for k, label, _ in NAV if k == key), "")
        if hasattr(self, "crumb"):
            self.crumb.configure(text=page_name)

    def _new_page(self, name):
        f = ctk.CTkFrame(self.page_host, fg_color=COLORS["bg"], corner_radius=0)
        f.grid(row=0, column=0, sticky="nsew", padx=20, pady=15)
        f.grid_remove()
        self.pages[name] = f
        return f

    def show_page(self, name):
        if name not in self.pages:
            return
        self._stop_live()
        for key, frame in self.pages.items():
            frame.grid_remove()
        for frame in self.detail_frames.values():
            frame.grid_remove()
        self.pages[name].grid()
        self._current_page = name
        self._activate_nav(name)

    def _show_detail(self, key, active_nav):
        self._stop_live()
        for frame in self.pages.values():
            frame.grid_remove()
        for k, frame in self.detail_frames.items():
            if k == key:
                frame.grid()
            else:
                frame.grid_remove()
        self._current_page = key
        self._activate_nav(active_nav)

    def _stop_live(self):
        if self._live_job:
            try:
                self.after_cancel(self._live_job)
            except Exception:
                pass
            self._live_job = None

    def _image_label(self, parent, pil_image, size):
        ci = ctk.CTkImage(light_image=pil_image, dark_image=pil_image, size=size)
        self._image_refs.append(ci)
        return ctk.CTkLabel(parent, text="", image=ci)

    # ------------------------------------------------------------------ pages
    def _build_all_pages(self):
        self._build_dashboard()
        self._build_servers()
        self._build_templates()
        self._build_plans()
        self._build_tasks()
        self._build_issues()
        self._build_reports()
        self._build_settings()
        self._build_task_detail()
        self._build_issue_detail()

    # ---------------------------------------------------------------- dashboard
    def _build_dashboard(self):
        page = self._new_page("dashboard")
        page.grid_rowconfigure(3, weight=1)
        page.grid_columnconfigure(0, weight=1)

        header = PageHeader(page, "工作台", "掌握基础设施健康状态，闭环处理今日巡检任务",
                            [{"text": "刷新数据", "kind": "secondary", "icon": "refresh",
                              "command": lambda: self.toast.show("数据已刷新，最后更新 10:42:18")},
                             {"text": "立即巡检", "kind": "primary", "icon": "play", "width": 104,
                              "command": self._open_inspection_dialog}])
        header.grid(row=0, column=0, sticky="ew")

        kpis = ctk.CTkFrame(page, fg_color="transparent", height=124)
        kpis.grid(row=1, column=0, sticky="ew", pady=(9, 0))
        kpis.grid_propagate(False)
        for i in range(4):
            kpis.grid_columnconfigure(i, weight=1, uniform="kpi")
        cards = [
            dict(title="服务器总数", value=f"{METRICS['total']}", suffix=" 台", note="本月新增 3 台 · 覆盖 4 个机房",
                 icon_name="server", tone="blue"),
            dict(title="在线率", value="97.9", suffix="%", note="47 / 48 台在线 · 1 台维护中", icon_name="activity",
                 tone="green", progress=0.979),
            dict(title="今日巡检", value="12 / 14", note="完成率 85.7% · 2 项执行中", icon_name="task",
                 tone="violet", progress=12 / 14),
            dict(title="待处理异常", value="6", suffix=" 项", note="严重 2 · 高危 4 · 较昨日 -2", icon_name="issue",
                 tone="red"),
        ]
        for i, kw in enumerate(cards):
            c = StatCard(kpis, **kw)
            c.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 6, 0 if i == 3 else 6))

        middle = ctk.CTkFrame(page, fg_color="transparent", height=206)
        middle.grid(row=2, column=0, sticky="ew", pady=(11, 0))
        middle.grid_propagate(False)
        middle.grid_columnconfigure(0, weight=30, uniform="mid")
        middle.grid_columnconfigure(1, weight=41, uniform="mid")
        middle.grid_columnconfigure(2, weight=29, uniform="mid")
        middle.grid_rowconfigure(0, weight=1)

        health = Card(middle, padding=14)
        health.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        hb = health.body
        ht = ctk.CTkFrame(hb, fg_color="transparent")
        ht.pack(fill="x")
        ctk.CTkLabel(ht, text="资产健康度", font=F(12.5, "bold"), text_color=COLORS["text"]).pack(side="left")
        text_button(ht, "查看资产  →", lambda: self.show_page("servers")).pack(side="right")
        hr = ctk.CTkFrame(hb, fg_color="transparent")
        hr.pack(fill="both", expand=True, pady=(2, 0))
        self._image_label(hr, charts.donut(METRICS["health"], METRICS["healthy"], METRICS["attention"],
                                           METRICS["risk"], size=130, thickness=14), (130, 130)).pack(
            side="left", padx=(0, 10))
        legend = ctk.CTkFrame(hr, fg_color="transparent")
        legend.pack(side="left", fill="both", expand=True, pady=(10, 0))
        for color, name, value in [("#22C55E", "健康", 41), ("#F59E0B", "需关注", 5), ("#EF4444", "风险", 2)]:
            row = ctk.CTkFrame(legend, fg_color="transparent")
            row.pack(fill="x", pady=2)
            ctk.CTkFrame(row, width=7, height=7, corner_radius=4, fg_color=color).pack(side="left",
                                                                                       padx=(0, 7))
            ctk.CTkLabel(row, text=name, font=F(9.8), text_color=COLORS["text_secondary"]).pack(side="left")
            ctk.CTkLabel(row, text=str(value), font=F(9.8, "bold"), text_color=COLORS["text"]).pack(side="right")
        ctk.CTkLabel(legend, text="较上周  +1.8%", font=F(8.7, "bold"), text_color=COLORS["success"],
                     anchor="w").pack(fill="x", pady=(9, 0))

        trend = Card(middle, padding=14)
        trend.grid(row=0, column=1, sticky="nsew", padx=6)
        tb = trend.body
        tt = ctk.CTkFrame(tb, fg_color="transparent")
        tt.pack(fill="x")
        ctk.CTkLabel(tt, text="巡检完成趋势", font=F(12.5, "bold"), text_color=COLORS["text"]).pack(side="left")
        ctk.CTkLabel(tt, text=" 近 7 天 ", font=F(8.4, "bold"), text_color=COLORS["text_muted"],
                     fg_color=COLORS["surface_alt"], corner_radius=7, height=20).pack(side="right")
        chart = charts.trend_chart((12, 13, 12, 14, 13, 14, 14), (10, 12, 11, 13, 12, 13, 12),
                                   ("10/22", "10/23", "10/24", "10/25", "10/26", "10/27", "10/28"),
                                   w=370, h=137)
        self._image_label(tb, chart, (370, 137)).pack(pady=(3, 0))
        ctk.CTkLabel(tb, text="日均完成 12.6 次  ·  计划达成率 96.4%", font=F(8.2),
                     text_color=COLORS["text_muted"], anchor="w").pack(fill="x")

        todo = Card(middle, padding=14)
        todo.grid(row=0, column=2, sticky="nsew", padx=(6, 0))
        tob = todo.body
        th = ctk.CTkFrame(tob, fg_color="transparent")
        th.pack(fill="x")
        ctk.CTkLabel(th, text="今日待办", font=F(12.5, "bold"), text_color=COLORS["text"]).pack(side="left")
        ctk.CTkLabel(th, text="4 项", font=F(8.7, "bold"), text_color=COLORS["primary"],
                     fg_color=COLORS["primary_soft"], corner_radius=7, height=20).pack(side="right")
        for title, meta, color in TODO_ITEMS:
            row = ctk.CTkFrame(tob, fg_color="transparent", height=24)
            row.pack(fill="x", pady=(3, 0))
            row.pack_propagate(False)
            ctk.CTkFrame(row, width=3, height=19, corner_radius=2, fg_color=color).pack(side="left",
                                                                                       padx=(0, 8))
            box = ctk.CTkFrame(row, fg_color="transparent")
            box.pack(side="left", fill="x", expand=True)
            ctk.CTkLabel(box, text=title, font=F(8.9), text_color=COLORS["text"], anchor="w").pack(fill="x")
            ctk.CTkLabel(box, text=meta, font=F(7.5), text_color=COLORS["text_muted"], anchor="w").pack(fill="x")
            ctk.CTkLabel(row, text="›", font=F(15), text_color=COLORS["text_muted"]).pack(side="right")
        text_button(tob, "查看全部待办  →", lambda: self.show_page("issues")).pack(anchor="w", pady=(3, 0))

        bottom = ctk.CTkFrame(page, fg_color="transparent")
        bottom.grid(row=3, column=0, sticky="nsew", pady=(11, 0))
        bottom.grid_columnconfigure(0, weight=68, uniform="bot")
        bottom.grid_columnconfigure(1, weight=32, uniform="bot")
        bottom.grid_rowconfigure(0, weight=1)

        recent = Card(bottom, padding=14)
        recent.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        rb = recent.body
        rh = ctk.CTkFrame(rb, fg_color="transparent")
        rh.pack(fill="x")
        ctk.CTkLabel(rh, text="最近巡检任务", font=F(12.5, "bold"), text_color=COLORS["text"]).pack(side="left")
        text_button(rh, "全部任务  →", lambda: self.show_page("tasks")).pack(side="right")
        cols = [
            {"key": "id", "title": "任务编号", "width": 100, "type": "mono", "size": 8.4},
            {"key": "name", "title": "巡检任务", "width": 180, "type": "stack", "sub": "scope", "size": 9.6},
            {"key": "executor", "title": "执行人", "width": 58, "type": "text", "size": 9.3},
            {"key": "status", "title": "状态", "width": 58, "type": "status"},
            {"key": "start", "title": "开始时间", "width": 92, "type": "text", "size": 8.8},
            {"key": "issues", "title": "异常", "width": 38, "type": "text", "anchor": "center",
             "color": COLORS["danger"], "weight": "bold"},
        ]
        t = DataTable(rb, cols, TASKS[:5], row_height=37, header_height=26,
                      on_row_click=lambda row: self.show_task_detail(row))
        t.pack(fill="both", expand=True, pady=(4, 0))

        alerts = Card(bottom, padding=14)
        alerts.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        ab = alerts.body
        ah = ctk.CTkFrame(ab, fg_color="transparent")
        ah.pack(fill="x")
        ctk.CTkLabel(ah, text="实时告警", font=F(12.5, "bold"), text_color=COLORS["text"]).pack(side="left")
        text_button(ah, "全部  →", lambda: self.show_page("issues"), size=8.6).pack(side="right")
        ctk.CTkLabel(ah, text=" 4 条未读 ", font=F(8.2, "bold"), text_color=COLORS["danger"],
                     fg_color=COLORS["danger_soft"], corner_radius=7, height=20).pack(side="right", padx=(0, 4))
        for title, sub, tm, level in ALERTS:
            fg, bg = level_palette(level)
            row = ctk.CTkFrame(ab, fg_color="transparent")
            row.pack(fill="x", pady=(7, 0))
            ctk.CTkFrame(row, width=5, height=28, corner_radius=3, fg_color=fg).pack(side="left", padx=(0, 8))
            box = ctk.CTkFrame(row, fg_color="transparent")
            box.pack(side="left", fill="x", expand=True)
            ctk.CTkLabel(box, text=title, font=F(9.4, "bold"), text_color=COLORS["text"],
                         anchor="w").pack(fill="x")
            ctk.CTkLabel(box, text=sub, font=F(8.0), text_color=COLORS["text_muted"], anchor="w").pack(fill="x")
            right = ctk.CTkFrame(row, fg_color="transparent")
            right.pack(side="right")
            ctk.CTkLabel(right, text=level, font=F(8.0, "bold"), text_color=fg).pack(anchor="e")
            ctk.CTkLabel(right, text=tm, font=F(7.5), text_color=COLORS["text_muted"]).pack(anchor="e")


    # ---------------------------------------------------------------- assets
    def _build_servers(self):
        page = self._new_page("servers")
        page.grid_rowconfigure(2, weight=1)
        page.grid_columnconfigure(0, weight=1)
        header = PageHeader(page, "服务器资产", "统一纳管服务器基础信息、健康状态与最近巡检结果",
                            [{"text": "导入资产", "kind": "secondary", "icon": "download", "width": 92,
                              "command": lambda: self.toast.show("导入向导已打开：支持 CSV / XLSX 模板", "warning")},
                             {"text": "新增服务器", "kind": "primary", "icon": "plus", "width": 106,
                              "command": self._open_add_server}])
        header.grid(row=0, column=0, sticky="ew")

        filter_card = Card(page, padding=11)
        filter_card.grid(row=1, column=0, sticky="ew", pady=(9, 0))
        filter_card.configure(height=58)
        filter_card.pack_propagate(False)
        fb = filter_card.body
        self.server_search = SearchBox(fb, "搜索名称 / IP / 业务组", width=238, height=34,
                                       command=lambda text: self._filter_servers(text))
        self.server_search.place(x=0, y=8)
        self.server_room = self._filter_menu(fb, ["全部机房", "A 机房", "B 机房", "测试机房"], 116,
                                             lambda v: self._filter_servers(self.server_search.entry.get()))
        self.server_room.place(x=246, y=8)
        self.server_os = self._filter_menu(fb, ["全部系统", "Linux", "Windows", "其他"], 112,
                                           lambda v: self._filter_servers(self.server_search.entry.get()))
        self.server_os.place(x=370, y=8)
        self.server_status = self._filter_menu(fb, ["全部状态", "在线", "已离线"], 104,
                                               lambda v: self._filter_servers(self.server_search.entry.get()))
        self.server_status.place(x=490, y=8)
        more = ctk.CTkButton(fb, text="更多筛选", image=icon("filter", COLORS["text_secondary"], 15), compound="left",
                             width=92, height=34, fg_color=COLORS["surface"], hover_color=COLORS["surface_alt"],
                             border_width=1, border_color=COLORS["border_strong"], corner_radius=8,
                             text_color=COLORS["text_secondary"], font=F(10.5),
                             command=lambda: self.toast.show("高级筛选：标签、负责人、健康度区间", "warning"))
        more.place(relx=1.0, x=-58, y=8, anchor="ne")
        reset = ctk.CTkButton(fb, text="重置", width=48, height=30, fg_color="transparent",
                              hover_color=COLORS["primary_soft"], text_color=COLORS["primary"], font=F(10.5, "bold"),
                              command=self._reset_server_filters)
        reset.place(relx=1.0, x=0, y=10, anchor="ne")

        table_card = Card(page, padding=14)
        table_card.grid(row=2, column=0, sticky="nsew", pady=(9, 0))
        tb = table_card.body
        th = ctk.CTkFrame(tb, fg_color="transparent")
        th.pack(fill="x")
        ctk.CTkLabel(th, text="资产清单", font=F(12.5, "bold"), text_color=COLORS["text"]).pack(side="left")
        self.server_count_label = ctk.CTkLabel(th, text="共 48 台  ·  在线 47  ·  待关注 7", font=F(9.3),
                                               text_color=COLORS["text_muted"])
        self.server_count_label.pack(side="left", padx=(10, 0))
        ctk.CTkLabel(th, text="数据同步于 10:42", font=F(8.5), text_color=COLORS["text_muted"]).pack(side="right")
        self.server_table_host = ctk.CTkFrame(tb, fg_color="transparent")
        self.server_table_host.pack(fill="both", expand=True, pady=(5, 0))
        self.server_total = 48
        self._render_server_table(SERVERS)

    def _filter_menu(self, master, values, width, command):
        return ctk.CTkOptionMenu(master, values=values, width=width, height=34, corner_radius=8,
                                 fg_color=COLORS["surface"], button_color=COLORS["surface"],
                                 button_hover_color=COLORS["surface_alt"], text_color=COLORS["text_secondary"],
                                 dropdown_fg_color=COLORS["surface"], dropdown_text_color=COLORS["text"],
                                 dropdown_hover_color=COLORS["primary_soft"], font=F(10.3),
                                 dropdown_font=F(10.3), command=command)

    def _render_server_table(self, rows):
        _clear(self.server_table_host)
        cols = [
            {"key": "name", "title": "服务器名称", "width": 150, "type": "stack", "sub": "ip", "size": 10.6},
            {"key": "ip", "title": "IP 地址", "width": 102, "type": "mono", "size": 9.4},
            {"key": "room", "title": "机房 / 机柜", "width": 110, "type": "text", "size": 9.5},
            {"key": "os", "title": "操作系统", "width": 112, "type": "text", "size": 9.3},
            {"key": "group", "title": "业务分组", "width": 84, "type": "text", "size": 9.4},
            {"key": "health", "title": "健康度", "width": 64, "type": "health"},
            {"key": "status", "title": "状态", "width": 64, "type": "status"},
            {"key": "last", "title": "最近巡检", "width": 86, "type": "text", "size": 9.1},
            {"key": "op", "title": "操作", "width": 42, "type": "actions",
             "actions": [("详情", "view")], "command": self._server_action},
        ]
        pages = max(1, (getattr(self, "server_total", 48) + 11) // 12)
        t = DataTable(self.server_table_host, cols, rows, row_height=39, header_height=31,
                      on_row_click=self._open_server_detail,
                      footer=f"共 {getattr(self, 'server_total', 48)} 条记录  ·  第 1 / {pages} 页",
                      footer_right=f"每页 12 条      ‹   " + "   ".join(str(i) for i in range(1, pages + 1)) + "   ›")
        t.pack(fill="both", expand=True)

    def _filter_servers(self, text):
        text = (text or "").strip().lower()
        room = getattr(self, "server_room", None)
        os_filter = getattr(self, "server_os", None)
        status_filter = getattr(self, "server_status", None)
        room_v = room.get() if room else "全部机房"
        os_v = os_filter.get() if os_filter else "全部系统"
        st_v = status_filter.get() if status_filter else "全部状态"
        rows = []
        for s in SERVERS:
            if text and text not in (s["name"] + s["ip"] + s["group"]).lower():
                continue
            if room_v != "全部机房" and room_v.split()[0] not in s["room"]:
                continue
            if os_v == "Linux" and "Windows" in s["os"]:
                continue
            if os_v == "Windows" and "Windows" not in s["os"]:
                continue
            if os_v == "其他" and ("Windows" in s["os"] or "Linux" in s["os"]):
                continue
            if st_v != "全部状态" and s["status"] != st_v:
                continue
            rows.append(s)
        self._render_server_table(rows)
        self.server_count_label.configure(text=f"筛选结果 {len(rows)} 台  ·  在线 {sum(1 for r in rows if r['status'] == '在线')}")

    def _reset_server_filters(self):
        self.server_search.entry.delete(0, "end")
        self.server_room.set("全部机房")
        self.server_os.set("全部系统")
        self.server_status.set("全部状态")
        self._render_server_table(SERVERS)
        self.server_count_label.configure(text="共 48 台  ·  在线 47  ·  待关注 7")

    def _server_action(self, row, action):
        self._open_server_detail(row)

    # ---------------------------------------------------------------- templates
    def _build_templates(self):
        page = self._new_page("templates")
        page.grid_rowconfigure(1, weight=1)
        page.grid_columnconfigure(0, weight=1)
        header = PageHeader(page, "巡检模板", "将巡检经验沉淀为可复用的检查项与判定规则",
                            [{"text": "从模板导入", "kind": "secondary", "icon": "download", "width": 106,
                              "command": lambda: self.toast.show("模板市场：共 12 个官方模板可导入", "warning")},
                             {"text": "新建模板", "kind": "primary", "icon": "plus", "width": 96,
                              "command": lambda: self.toast.show("新建模板向导已打开", "warning")}])
        header.grid(row=0, column=0, sticky="ew")

        content = ctk.CTkFrame(page, fg_color="transparent")
        content.grid(row=1, column=0, sticky="nsew", pady=(9, 0))
        content.grid_columnconfigure(0, minsize=286)
        content.grid_columnconfigure(1, weight=1)
        content.grid_rowconfigure(0, weight=1)

        left = Card(content, padding=12)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        lb = left.body
        lh = ctk.CTkFrame(lb, fg_color="transparent")
        lh.pack(fill="x")
        ctk.CTkLabel(lh, text="模板库", font=F(12.5, "bold"), text_color=COLORS["text"]).pack(side="left")
        ctk.CTkLabel(lh, text="4 个", font=F(8.6, "bold"), text_color=COLORS["text_muted"]).pack(side="right")
        ctk.CTkLabel(lb, text="按业务场景维护检查项组合", font=F(8.8), text_color=COLORS["text_muted"],
                     anchor="w").pack(fill="x", pady=(1, 7))
        self.template_items = []
        self.template_index = 0
        for i, tpl in enumerate(TEMPLATES):
            self.template_items.append(self._template_item(lb, i, tpl))
        new_btn = ctk.CTkButton(lb, text="  +  创建空白模板", height=40, fg_color="transparent",
                                border_width=1, border_color=COLORS["border_strong"], text_color=COLORS["text_secondary"],
                                hover_color=COLORS["surface_alt"], corner_radius=8, font=F(9.8),
                                command=lambda: self.toast.show("新建模板向导已打开", "warning"))
        new_btn.pack(fill="x", pady=(8, 0))
        ctk.CTkLabel(lb, text="提示：模板修改后仅影响后续新任务", font=F(8.2), text_color=COLORS["text_muted"],
                     anchor="w").pack(fill="x", pady=(10, 0))

        self.template_detail = Card(content, padding=16)
        self.template_detail.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        self._render_template_detail(0)

    def _template_item(self, parent, index, tpl):
        active = index == 0
        f = ctk.CTkFrame(parent, fg_color=COLORS["primary_soft"] if active else COLORS["surface"],
                         border_width=1, border_color="#BBD0F8" if active else COLORS["border"],
                         corner_radius=9, height=75)
        f.pack(fill="x", pady=(0, 7))
        f.pack_propagate(False)
        f.grid_columnconfigure(1, weight=1)
        chip = ctk.CTkFrame(f, width=35, height=35, corner_radius=9,
                            fg_color="#FFFFFF" if active else COLORS["surface_alt"])
        chip.grid(row=0, column=0, rowspan=2, padx=(10, 8), pady=12)
        chip.grid_propagate(False)
        ctk.CTkLabel(chip, text="", image=icon(tpl["icon"], tpl["color"], 18)).pack(expand=True)
        name = ctk.CTkLabel(f, text=tpl["name"], font=F(9.9, "bold"), text_color=COLORS["text"], anchor="w")
        name.grid(row=0, column=1, sticky="ew", pady=(13, 0))
        meta = ctk.CTkLabel(f, text=f"{tpl['items']} 项 · {tpl['servers']} 台服务器 · {tpl['version']}",
                            font=F(8.3), text_color=COLORS["text_muted"], anchor="w")
        meta.grid(row=1, column=1, sticky="ew", pady=(0, 12))
        for w in (f, chip, name, meta):
            w.bind("<Button-1>", lambda e, idx=index: self._select_template(idx))
            try:
                w.configure(cursor="hand2")
            except Exception:
                pass
        return f

    def _select_template(self, index):
        self.template_index = index
        for i, frame in enumerate(self.template_items):
            active = i == index
            frame.configure(fg_color=COLORS["primary_soft"] if active else COLORS["surface"],
                            border_color="#BBD0F8" if active else COLORS["border"])
        self._render_template_detail(index)

    def _render_template_detail(self, index):
        _clear(self.template_detail.body)
        tpl = TEMPLATES[index]
        b = self.template_detail.body
        top = ctk.CTkFrame(b, fg_color="transparent")
        top.pack(fill="x")
        left = ctk.CTkFrame(top, fg_color="transparent")
        left.pack(side="left")
        line = ctk.CTkFrame(left, fg_color="transparent")
        line.pack(anchor="w")
        ctk.CTkLabel(line, text=tpl["name"], font=F(17, "bold"), text_color=COLORS["text"]).pack(side="left")
        ctk.CTkLabel(line, text=f"  {tpl['version']}  ", font=F(8.3, "bold"), text_color=COLORS["primary"],
                     fg_color=COLORS["primary_soft"], corner_radius=7, height=20).pack(side="left", padx=(8, 0))
        ctk.CTkLabel(left, text=tpl["desc"], font=F(9.5), text_color=COLORS["text_muted"], anchor="w").pack(
            anchor="w", pady=(4, 0))
        actions = ctk.CTkFrame(top, fg_color="transparent")
        actions.pack(side="right")
        action_button(actions, "复制", lambda: self.toast.show("已复制为新模板草稿"), "secondary", "copy", 66, 32).pack(
            side="left", padx=(0, 6))
        action_button(actions, "编辑模板", lambda: self.toast.show("模板编辑器已打开", "warning"), "primary",
                      "edit", 88, 32).pack(side="left")

        tiles = ctk.CTkFrame(b, fg_color="transparent")
        tiles.pack(fill="x", pady=(12, 10))
        for i, (lab, val, sub) in enumerate([("检查项", str(tpl["items"]), "覆盖 6 类指标"),
                                             ("关联服务器", str(tpl["servers"]), "自动继承模板更新"),
                                             ("最近更新", tpl["updated"][5:], "由 李明 维护")]):
            tile = ctk.CTkFrame(tiles, fg_color=COLORS["surface_alt"], corner_radius=8, height=58)
            tile.pack(side="left", fill="x", expand=True, padx=(0 if i == 0 else 6, 0))
            ctk.CTkLabel(tile, text=lab, font=F(8.5), text_color=COLORS["text_muted"], anchor="w").pack(
                fill="x", padx=10, pady=(8, 0))
            row = ctk.CTkFrame(tile, fg_color="transparent")
            row.pack(fill="x", padx=10)
            ctk.CTkLabel(row, text=val, font=F(14, "bold"), text_color=COLORS["text"]).pack(side="left")
            ctk.CTkLabel(row, text=sub, font=F(7.7), text_color=COLORS["text_muted"]).pack(side="right",
                                                                                            pady=(4, 0))

        ctk.CTkFrame(b, fg_color=COLORS["border"], height=1).pack(fill="x", pady=(2, 10))
        ch = ctk.CTkFrame(b, fg_color="transparent")
        ch.pack(fill="x")
        ctk.CTkLabel(ch, text="检查项配置", font=F(11.5, "bold"), text_color=COLORS["text"]).pack(side="left")
        ctk.CTkLabel(ch, text="按严重级别排序", font=F(8.6), text_color=COLORS["text_muted"]).pack(side="left",
                                                                                                  padx=(8, 0))
        text_button(ch, "调整顺序", lambda: self.toast.show("已进入检查项排序模式", "warning")).pack(side="right")
        cols = [
            {"key": "name", "title": "检查项", "width": 170, "type": "text", "size": 9.9, "weight": "bold",
             "color": COLORS["text"]},
            {"key": "method", "title": "采集方式", "width": 95, "type": "text", "size": 9.2},
            {"key": "rule", "title": "判定标准", "width": 235, "type": "text", "size": 9.2},
            {"key": "level", "title": "级别", "width": 58, "type": "level"},
        ]
        rows = [{"name": a, "method": m, "rule": r, "level": lv} for a, m, r, lv in CHECK_ITEMS]
        t = DataTable(b, cols, rows, row_height=39, header_height=30,
                      footer=f"显示 13 / {tpl['items']} 项", footer_right="查看全部检查项  →")
        t.pack(fill="both", expand=True, pady=(4, 0))

    # ---------------------------------------------------------------- plans
    def _build_plans(self):
        page = self._new_page("plans")
        page.grid_rowconfigure(2, weight=1)
        page.grid_columnconfigure(0, weight=1)
        header = PageHeader(page, "巡检计划", "按业务节奏配置自动巡检，减少人工漏检",
                            [{"text": "执行记录", "kind": "secondary", "icon": "clock", "width": 92,
                              "command": lambda: self.show_page("tasks")},
                             {"text": "新建计划", "kind": "primary", "icon": "plus", "width": 96,
                              "command": lambda: self.toast.show("新建计划向导已打开", "warning")}])
        header.grid(row=0, column=0, sticky="ew")

        banner = Card(page, padding=13)
        banner.grid(row=1, column=0, sticky="ew", pady=(9, 0))
        bb = banner.body
        bb.grid_columnconfigure(1, weight=1)
        chip = ctk.CTkFrame(bb, width=36, height=36, corner_radius=9, fg_color=COLORS["primary_soft"])
        chip.grid(row=0, column=0, rowspan=2, padx=(0, 11))
        chip.grid_propagate(False)
        ctk.CTkLabel(chip, text="", image=icon("calendar", COLORS["primary"], 18)).pack(expand=True)
        ctk.CTkLabel(bb, text="本月计划执行率 96.4%", font=F(11, "bold"), text_color=COLORS["text"],
                     anchor="w").grid(row=0, column=1, sticky="w")
        ctk.CTkLabel(bb, text="共执行 326 次  ·  失败 8 次  ·  自动重试 6 次  ·  最近一次调度 10:30",
                     font=F(8.8), text_color=COLORS["text_muted"], anchor="w").grid(row=1, column=1, sticky="w")
        ctk.CTkLabel(bb, text="下一次调度  10 月 28 日 14:00", font=F(9.2, "bold"),
                     text_color=COLORS["primary"]).grid(row=0, column=2, rowspan=2, padx=(10, 0))
        action_button(bb, "查看调度日历", lambda: self.toast.show("调度日历：本周共 41 次计划执行", "warning"),
                      "secondary", "calendar", 110, 32).grid(row=0, column=3, rowspan=2, padx=(12, 0))

        table_card = Card(page, padding=14)
        table_card.grid(row=2, column=0, sticky="nsew", pady=(9, 0))
        tb = table_card.body
        th = ctk.CTkFrame(tb, fg_color="transparent")
        th.pack(fill="x")
        ctk.CTkLabel(th, text="巡检计划", font=F(12.5, "bold"), text_color=COLORS["text"]).pack(side="left")
        ctk.CTkLabel(th, text="启用的计划将按 Cron 表达式自动触发", font=F(8.8),
                     text_color=COLORS["text_muted"]).pack(side="left", padx=(10, 0))
        ctk.CTkLabel(th, text="启用 7  ·  停用 3", font=F(8.8), text_color=COLORS["text_muted"]).pack(side="right")
        cols = [
            {"key": "name", "title": "计划名称", "width": 205, "type": "stack", "sub": "scope", "size": 10.2},
            {"key": "template", "title": "巡检模板", "width": 145, "type": "text", "size": 9.4},
            {"key": "freq", "title": "执行频率", "width": 96, "type": "text", "size": 9.5, "weight": "bold",
             "color": COLORS["text_secondary"]},
            {"key": "next", "title": "下次执行", "width": 104, "type": "text", "size": 9.2},
            {"key": "notify", "title": "通知方式", "width": 106, "type": "text", "size": 9.1},
            {"key": "status", "title": "状态", "width": 58, "type": "status"},
            {"key": "op", "title": "操作", "width": 56, "type": "actions",
             "actions": [("编辑", "edit")], "command": self._plan_action},
        ]
        t = DataTable(tb, cols, PLANS, row_height=48, header_height=32,
                      on_row_click=lambda row: self.toast.show(f"计划「{row['name']}」详情已打开", "warning"),
                      footer="共 10 个计划  ·  本周计划执行 41 次", footer_right="按下次执行时间排序")
        t.pack(fill="both", expand=True, pady=(6, 0))

    def _plan_action(self, row, action):
        self.toast.show(f"已打开计划「{row['name']}」编辑器", "warning")

    # ---------------------------------------------------------------- tasks
    def _build_tasks(self):
        page = self._new_page("tasks")
        page.grid_rowconfigure(3, weight=1)
        page.grid_columnconfigure(0, weight=1)
        header = PageHeader(page, "巡检任务", "跟踪每一次巡检的执行进度、日志与异常结果",
                            [{"text": "导出记录", "kind": "secondary", "icon": "download", "width": 92,
                              "command": lambda: self.toast.show("任务记录已导出为 CSV")},
                             {"text": "立即巡检", "kind": "primary", "icon": "play", "width": 104,
                              "command": self._open_inspection_dialog}])
        header.grid(row=0, column=0, sticky="ew")
        tab_wrap = ctk.CTkFrame(page, fg_color="transparent")
        tab_wrap.grid(row=1, column=0, sticky="ew", pady=(10, 0))
        self.task_tabs = TabBar(tab_wrap, [("全部", 28), ("执行中", 2), ("已完成", 24), ("失败", 2)], active=0,
                                command=self._filter_tasks)
        self.task_tabs.pack(side="left")

        filter_line = ctk.CTkFrame(page, fg_color="transparent")
        filter_line.grid(row=2, column=0, sticky="ew", pady=(8, 0))
        filter_line.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(filter_line, text="最近 7 天", font=F(9.6, "bold"), text_color=COLORS["text_secondary"],
                     fg_color=COLORS["surface"], corner_radius=7, height=28).pack(side="left", padx=(0, 6))
        ctk.CTkLabel(filter_line, text="共 28 条任务记录", font=F(9.2), text_color=COLORS["text_muted"]).pack(
            side="left")
        ctk.CTkLabel(filter_line, text="成功率 92.9%", font=F(9.2, "bold"), text_color=COLORS["success"]).pack(
            side="right", padx=(8, 0))
        ctk.CTkLabel(filter_line, text="自动刷新", font=F(8.8), text_color=COLORS["text_muted"]).pack(side="right")

        table_card = Card(page, padding=14)
        table_card.grid(row=3, column=0, sticky="nsew", pady=(8, 0))
        self.task_table_host = table_card.body
        self._render_task_table(TASKS)

    def _render_task_table(self, rows):
        _clear(self.task_table_host)
        cols = [
            {"key": "id", "title": "任务编号", "width": 116, "type": "mono", "size": 8.7},
            {"key": "name", "title": "任务名称 / 巡检范围", "width": 210, "type": "stack", "sub": "scope",
             "size": 10.3},
            {"key": "start", "title": "开始时间", "width": 106, "type": "text", "size": 8.9},
            {"key": "executor", "title": "执行人", "width": 70, "type": "text", "size": 9.3},
            {"key": "progress", "title": "执行进度", "width": 126, "type": "progress"},
            {"key": "status", "title": "状态", "width": 62, "type": "status"},
            {"key": "issues", "title": "异常", "width": 44, "type": "text", "anchor": "center",
             "color": COLORS["danger"], "weight": "bold"},
            {"key": "op", "title": "操作", "width": 46, "type": "actions",
             "actions": [("查看", "view")], "command": self._task_action},
        ]
        t = DataTable(self.task_table_host, cols, rows, row_height=46, header_height=34,
                      on_row_click=lambda row: self.show_task_detail(row),
                      footer=f"显示 {len(rows)} / 28 条记录", footer_right="第 1 / 3 页      按开始时间倒序")
        t.pack(fill="both", expand=True)

    def _filter_tasks(self, index):
        status_map = {0: None, 1: "执行中", 2: "已完成", 3: "失败"}
        status = status_map.get(index)
        rows = TASKS if status is None else [t for t in TASKS if t["status"] == status]
        self._render_task_table(rows)

    def _task_action(self, row, action):
        self.show_task_detail(row)

    # ---------------------------------------------------------------- issues
    def _build_issues(self):
        page = self._new_page("issues")
        page.grid_rowconfigure(3, weight=1)
        page.grid_columnconfigure(0, weight=1)
        header = PageHeader(page, "异常工单", "从发现、指派、处置到复核，形成可追溯的闭环",
                            [{"text": "导出工单", "kind": "secondary", "icon": "download", "width": 92,
                              "command": lambda: self.toast.show("工单清单已导出为 XLSX")},
                             {"text": "批量指派", "kind": "primary", "icon": "user", "width": 94,
                              "command": lambda: self.toast.show("请选择需要指派的工单", "warning")}])
        header.grid(row=0, column=0, sticky="ew")

        stats = ctk.CTkFrame(page, fg_color="transparent", height=92)
        stats.grid(row=1, column=0, sticky="ew", pady=(9, 0))
        stats.grid_propagate(False)
        for i in range(4):
            stats.grid_columnconfigure(i, weight=1, uniform="ist")
        items = [
            ("严重", "2", "2 项待处置", "issue", "red"),
            ("高危", "4", "平均响应 18 分钟", "activity", "amber"),
            ("处理中", "3", "已指派 1 项", "clock", "blue"),
            ("今日闭环", "7", "闭环率 94.3%", "check", "green"),
        ]
        for i, (title, val, note, ic, tone) in enumerate(items):
            c = StatCard(stats, title=title, value=val, note=note, icon_name=ic, tone=tone)
            c.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 6, 0 if i == 3 else 6))

        filter_card = Card(page, padding=10)
        filter_card.grid(row=2, column=0, sticky="ew", pady=(9, 0))
        fb = filter_card.body
        fb.grid_columnconfigure(4, weight=1)
        self.issue_search = SearchBox(fb, "搜索工单号 / 服务器 / 负责人", width=270, height=33,
                                      command=lambda v: self.toast.show("已按关键字筛选工单"))
        self.issue_search.grid(row=0, column=0, padx=(0, 8))
        self.issue_level = self._filter_menu(fb, ["全部级别", "严重", "高危", "中", "低"], 104,
                                             lambda v: self.toast.show(f"筛选级别：{v}"))
        self.issue_level.grid(row=0, column=1, padx=(0, 8))
        self.issue_status = self._filter_menu(fb, ["全部状态", "待处理", "处理中", "已闭环"], 104,
                                              lambda v: self.toast.show(f"筛选状态：{v}"))
        self.issue_status.grid(row=0, column=2, padx=(0, 8))
        ctk.CTkLabel(fb, text="SLA 超时提醒已开启", font=F(8.8), text_color=COLORS["success"]).grid(
            row=0, column=3, padx=(4, 0))

        table_card = Card(page, padding=10)
        table_card.grid(row=3, column=0, sticky="nsew", pady=(9, 0))
        tb = table_card.body
        th = ctk.CTkFrame(tb, fg_color="transparent")
        th.pack(fill="x")
        ctk.CTkLabel(th, text="待处置异常", font=F(12.5, "bold"), text_color=COLORS["text"]).pack(side="left")
        ctk.CTkLabel(th, text="按 SLA 剩余时间升序", font=F(8.8), text_color=COLORS["text_muted"]).pack(
            side="left", padx=(9, 0))
        ctk.CTkLabel(th, text="6 项未闭环  ·  2 项即将超时", font=F(8.8, "bold"),
                     text_color=COLORS["danger"]).pack(side="right")
        cols = [
            {"key": "id", "title": "工单号", "width": 108, "type": "mono", "size": 8.4},
            {"key": "title", "title": "异常摘要", "width": 218, "type": "stack", "sub": "server", "size": 9.9},
            {"key": "level", "title": "级别", "width": 55, "type": "level"},
            {"key": "source", "title": "来源", "width": 136, "type": "text", "size": 8.9},
            {"key": "owner", "title": "负责人", "width": 64, "type": "text", "size": 9.2},
            {"key": "sla", "title": "SLA 剩余", "width": 108, "type": "text", "size": 8.8},
            {"key": "status", "title": "状态", "width": 64, "type": "status"},
            {"key": "op", "title": "操作", "width": 48, "type": "actions",
             "actions": [("处理", "view")], "command": self._issue_action},
        ]
        t = DataTable(tb, cols, ISSUES, row_height=36, header_height=28,
                      on_row_click=lambda row: self.show_issue_detail(row),
                      footer="共 8 条记录  ·  已完成 1 条", footer_right="自动刷新于 10:42")
        t.pack(fill="both", expand=True, pady=(5, 0))

    def _issue_action(self, row, action):
        self.show_issue_detail(row)

    # ---------------------------------------------------------------- reports
    def _build_reports(self):
        page = self._new_page("reports")
        page.grid_rowconfigure(2, weight=1)
        page.grid_columnconfigure(0, weight=1)
        header = PageHeader(page, "报表中心", "汇总巡检结果与异常趋势，一键生成可交付的运维报告",
                            [{"text": "报告归档", "kind": "secondary", "icon": "file", "width": 92,
                              "command": lambda: self.toast.show("已打开报告归档，共 18 份")},
                             {"text": "生成报告", "kind": "primary", "icon": "file", "width": 100,
                              "command": self._generate_report}])
        header.grid(row=0, column=0, sticky="ew")

        filter_card = Card(page, padding=11)
        filter_card.grid(row=1, column=0, sticky="ew", pady=(9, 0))
        fb = filter_card.body
        fb.grid_columnconfigure(4, weight=1)
        self.report_type = self._filter_menu(fb, ["月度巡检报告", "每日巡检报告", "每周巡检报告", "专项巡检报告"],
                                             132, lambda v: self.toast.show(f"已切换报告类型：{v}"))
        self.report_type.grid(row=0, column=0, padx=(0, 8))
        ctk.CTkLabel(fb, text="2026-10-01  至  2026-10-28", font=F(9.6), text_color=COLORS["text_secondary"],
                     fg_color=COLORS["surface_alt"], corner_radius=7, height=34).grid(row=0, column=1,
                                                                                     padx=(0, 8), ipadx=10)
        self.report_scope = self._filter_menu(fb, ["全部业务组", "生产核心组", "数据库组", "Web 应用组"], 120,
                                              lambda v: self.toast.show(f"统计范围：{v}"))
        self.report_scope.grid(row=0, column=2, padx=(0, 8))
        ctk.CTkLabel(fb, text="数据截至 10-28 10:42", font=F(8.6), text_color=COLORS["text_muted"]).grid(
            row=0, column=3, padx=(4, 0))
        action_button(fb, "重新生成", self._generate_report, "secondary", "refresh", 94, 34).grid(
            row=0, column=5, padx=(0, 6))
        action_button(fb, "导出 PDF", lambda: self.toast.show("报告已导出为 PDF（演示）"), "ghost", "download",
                      88, 34).grid(row=0, column=6)

        content = ctk.CTkFrame(page, fg_color="transparent")
        content.grid(row=2, column=0, sticky="nsew", pady=(9, 0))
        content.grid_columnconfigure(0, weight=69, uniform="rep")
        content.grid_columnconfigure(1, weight=31, uniform="rep")
        content.grid_rowconfigure(0, weight=1)

        preview = Card(content, padding=16)
        preview.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        pb = preview.body
        top = ctk.CTkFrame(pb, fg_color="transparent")
        top.pack(fill="x")
        ctk.CTkLabel(top, text="", image=logo_image(28), width=28).pack(side="left", padx=(0, 9))
        box = ctk.CTkFrame(top, fg_color="transparent")
        box.pack(side="left")
        ctk.CTkLabel(box, text="2026 年 10 月服务器巡检月报", font=F(13.4, "bold"), text_color=COLORS["text"],
                     anchor="w").pack(anchor="w")
        ctk.CTkLabel(box, text="统计周期 2026-10-01 ~ 2026-10-28  ·  生成时间 2026-10-28 09:40",
                     font=F(8.3), text_color=COLORS["text_muted"], anchor="w").pack(anchor="w")
        Pill(top, "预览", "#2563EB", "#EAF1FF").pack(side="right")

        tiles = ctk.CTkFrame(pb, fg_color="transparent")
        tiles.pack(fill="x", pady=(10, 7))
        for i, (val, lab, note) in enumerate([("326", "巡检任务", "完成率 98.2%"), ("92.6", "平均健康度", "较上月 +1.8"),
                                               ("94.3%", "异常闭环率", "平均处置 42 分钟")]):
            tile = ctk.CTkFrame(tiles, fg_color=COLORS["surface_alt"], corner_radius=8, height=53)
            tile.pack(side="left", fill="x", expand=True, padx=(0 if i == 0 else 6, 0))
            tile.pack_propagate(False)
            ctk.CTkLabel(tile, text=val, font=F(15, "bold"), text_color=COLORS["text"]).pack(side="left",
                                                                                             padx=(10, 4), pady=14)
            b = ctk.CTkFrame(tile, fg_color="transparent")
            b.pack(side="left", pady=9)
            ctk.CTkLabel(b, text=lab, font=F(8.2), text_color=COLORS["text_muted"], anchor="w").pack(anchor="w")
            ctk.CTkLabel(b, text=note, font=F(7.5), text_color=COLORS["success"], anchor="w").pack(anchor="w")

        charts_box = ctk.CTkFrame(pb, fg_color="transparent")
        charts_box.pack(fill="x", pady=(2, 4))
        left_chart = ctk.CTkFrame(charts_box, fg_color="transparent")
        left_chart.pack(side="left", fill="x", expand=True)
        ctk.CTkLabel(left_chart, text="每日巡检任务趋势", font=F(9.4, "bold"), text_color=COLORS["text"],
                     anchor="w").pack(fill="x")
        vals = (14, 17, 15, 19, 16, 18, 12, 20, 18, 21, 17, 22, 19, 18)
        self._image_label(left_chart, charts.bar_chart(tuple(vals), tuple(f"10/{i+15}" for i in range(14)), w=565, h=208),
                          (565, 208)).pack(anchor="w")
        right_chart = ctk.CTkFrame(charts_box, fg_color="transparent", width=212)
        right_chart.pack(side="right", fill="y", padx=(12, 0))
        right_chart.pack_propagate(False)
        ctk.CTkLabel(right_chart, text="异常级别分布", font=F(9.4, "bold"), text_color=COLORS["text"],
                     anchor="w").pack(fill="x", pady=(0, 10))
        for name, value, color, total in [("严重", 12, "#DC2626", 57), ("高危", 18, "#D97706", 57),
                                          ("中", 19, "#2563EB", 57), ("低", 8, "#94A3B8", 57)]:
            row = ctk.CTkFrame(right_chart, fg_color="transparent")
            row.pack(fill="x", pady=3)
            ctk.CTkLabel(row, text=name, font=F(8.4), text_color=COLORS["text_secondary"], width=24).pack(side="left")
            bar = ctk.CTkProgressBar(row, height=7, width=116, corner_radius=4, fg_color=COLORS["track"],
                                     progress_color=color)
            bar.pack(side="left", padx=(2, 6))
            bar.set(value / total)
            ctk.CTkLabel(row, text=str(value), font=F(8.4, "bold"), text_color=COLORS["text"]).pack(side="right")
        ctk.CTkLabel(right_chart, text="本月异常共 57 项\n闭环 54 项，剩余 3 项", font=F(8.3),
                     text_color=COLORS["text_muted"], justify="left", anchor="w").pack(fill="x", pady=(11, 0))

        focus = ctk.CTkFrame(pb, fg_color="transparent")
        focus.pack(fill="x", pady=(4, 3))
        fh = ctk.CTkFrame(focus, fg_color="transparent")
        fh.pack(fill="x", pady=(0, 4))
        ctk.CTkLabel(fh, text="重点异常", font=F(9.4, "bold"), text_color=COLORS["text"]).pack(side="left")
        ctk.CTkLabel(fh, text="按影响范围与 SLA 排序", font=F(7.8), text_color=COLORS["text_muted"]).pack(
            side="left", padx=(7, 0))
        for title, server, level in [("磁盘使用率持续超过 90%", "prod-db-02", "严重"),
                                     ("数据库主从延迟 186s", "prod-db-01", "严重"),
                                     ("备份任务连续 2 次失败", "prod-backup-01", "高危")]:
            row = ctk.CTkFrame(focus, fg_color=COLORS["surface_alt"], corner_radius=6, height=28)
            row.pack(fill="x", pady=(0, 3))
            row.pack_propagate(False)
            ctk.CTkLabel(row, text="", image=icon("issue", level_palette(level)[0], 13), width=22).pack(
                side="left", padx=(8, 2))
            ctk.CTkLabel(row, text=title, font=F(8.4), text_color=COLORS["text"], anchor="w").pack(
                side="left", fill="x", expand=True)
            ctk.CTkLabel(row, text=server, font=("Consolas", 7.7), text_color=COLORS["text_muted"]).pack(
                side="right", padx=(6, 8))
            Pill(row, level, *level_palette(level), size=7.3).pack(side="right")

        ctk.CTkFrame(pb, fg_color="transparent", height=2).pack(fill="both", expand=True)
        ctk.CTkFrame(pb, fg_color=COLORS["border"], height=1).pack(fill="x", pady=(1, 6))
        ctk.CTkLabel(pb, text="结论：本月基础设施整体运行平稳，核心业务可用性 99.96%。订单数据库磁盘容量与备份任务需重点跟进。",
                     font=F(8.9), text_color=COLORS["text_secondary"], anchor="w", wraplength=720,
                     justify="left").pack(fill="x")

        side = ctk.CTkFrame(content, fg_color="transparent")
        side.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        side.grid_rowconfigure(0, weight=1)
        side.grid_rowconfigure(1, weight=1)
        templates = Card(side, padding=13)
        templates.grid(row=0, column=0, sticky="nsew", pady=(0, 6))
        tb = templates.body
        ctk.CTkLabel(tb, text="报告模板", font=F(12, "bold"), text_color=COLORS["text"], anchor="w").pack(fill="x")
        ctk.CTkLabel(tb, text="选择模板快速创建标准报告", font=F(8.4), text_color=COLORS["text_muted"],
                     anchor="w").pack(fill="x", pady=(1, 6))
        for name, sub, ic, color in [("月度巡检报告", "资产健康与异常趋势", "calendar", "#2563EB"),
                                     ("每日巡检日报", "当日任务与告警摘要", "report", "#0891B2"),
                                     ("专项分析报告", "数据库 / 安全 / 备份", "database", "#7C3AED")]:
            row = ctk.CTkFrame(tb, fg_color=COLORS["surface_alt"], corner_radius=7, height=44)
            row.pack(fill="x", pady=(0, 5))
            row.pack_propagate(False)
            ctk.CTkLabel(row, text="", image=icon(ic, color, 15), width=26).pack(side="left", padx=(9, 2))
            b = ctk.CTkFrame(row, fg_color="transparent")
            b.pack(side="left", pady=4)
            ctk.CTkLabel(b, text=name, font=F(8.9, "bold"), text_color=COLORS["text"], anchor="w").pack(anchor="w")
            ctk.CTkLabel(b, text=sub, font=F(7.5), text_color=COLORS["text_muted"], anchor="w").pack(anchor="w")

        history = Card(side, padding=13)
        history.grid(row=1, column=0, sticky="nsew", pady=(6, 0))
        hb = history.body
        hh = ctk.CTkFrame(hb, fg_color="transparent")
        hh.pack(fill="x")
        ctk.CTkLabel(hh, text="最近生成", font=F(12, "bold"), text_color=COLORS["text"]).pack(side="left")
        text_button(hh, "全部  →", lambda: self.toast.show("已打开报告归档")).pack(side="right")
        for name, kind, tm, st, size in REPORT_HISTORY:
            row = ctk.CTkFrame(hb, fg_color="transparent", height=40)
            row.pack(fill="x", pady=(4, 0))
            ctk.CTkLabel(row, text="", image=icon("file", COLORS["primary"], 15), width=23).pack(side="left",
                                                                                               padx=(0, 2))
            b = ctk.CTkFrame(row, fg_color="transparent")
            b.pack(side="left", fill="x", expand=True)
            ctk.CTkLabel(b, text=name, font=F(8.6, "bold"), text_color=COLORS["text"], anchor="w").pack(fill="x")
            ctk.CTkLabel(b, text=f"{kind}  ·  {tm}", font=F(7.3), text_color=COLORS["text_muted"],
                         anchor="w").pack(fill="x")
            Pill(row, st, "#D97706" if st == "生成中" else "#16A34A",
                 "#FFF5E5" if st == "生成中" else "#E9F8EF", size=7.6).pack(side="right", padx=(4, 0))

    def _generate_report(self):
        self.toast.show("报告生成任务已提交，预计 20 秒完成")

    # ---------------------------------------------------------------- settings
    def _build_settings(self):
        page = self._new_page("settings")
        page.grid_rowconfigure(1, weight=1)
        page.grid_columnconfigure(1, weight=1)
        header = PageHeader(page, "系统设置", "管理基础信息、通知渠道、成员权限与审计记录")
        header.grid(row=0, column=0, columnspan=2, sticky="ew")

        left = Card(page, padding=12)
        left.grid(row=1, column=0, sticky="nsew", pady=(9, 0), padx=(0, 6))
        left.configure(width=210)
        left.grid_propagate(False)
        lb = left.body
        user = ctk.CTkFrame(lb, fg_color=COLORS["surface_alt"], corner_radius=8, height=62)
        user.pack(fill="x")
        user.pack_propagate(False)
        ctk.CTkLabel(user, text="李", width=34, height=34, fg_color=COLORS["primary"], corner_radius=17,
                     text_color="#FFFFFF", font=F(12, "bold")).pack(side="left", padx=10)
        ub = ctk.CTkFrame(user, fg_color="transparent")
        ub.pack(side="left", pady=11)
        ctk.CTkLabel(ub, text="李明", font=F(10, "bold"), text_color=COLORS["text"], anchor="w").pack(anchor="w")
        ctk.CTkLabel(ub, text="超级管理员", font=F(8.3), text_color=COLORS["text_muted"], anchor="w").pack(anchor="w")
        ctk.CTkFrame(lb, fg_color=COLORS["border"], height=1).pack(fill="x", pady=10)
        self.settings_nav = {}
        for key, label, ic in [("basic", "基础设置", "settings"), ("notify", "通知渠道", "bell"),
                               ("users", "用户与角色", "user"), ("audit", "审计日志", "file"),
                               ("about", "关于系统", "shield")]:
            b = ctk.CTkButton(lb, text="   " + label, image=icon(ic, COLORS["text_secondary"], 16), compound="left",
                              anchor="w", height=36, fg_color="transparent", hover_color=COLORS["surface_alt"],
                              text_color=COLORS["text_secondary"], font=F(10.4), corner_radius=7,
                              command=lambda k=key: self._settings_section(k))
            b.pack(fill="x", pady=1)
            self.settings_nav[key] = b
        ctk.CTkFrame(lb, fg_color=COLORS["border"], height=1).pack(fill="x", pady=10)
        ctk.CTkLabel(lb, text="配置变更将记录审计日志", font=F(8.2), text_color=COLORS["text_muted"],
                     wraplength=165, justify="left", anchor="w").pack(fill="x")

        self.settings_host = ctk.CTkFrame(page, fg_color="transparent")
        self.settings_host.grid(row=1, column=1, sticky="nsew", pady=(9, 0), padx=(6, 0))
        self.settings_host.grid_rowconfigure(0, weight=1)
        self.settings_host.grid_columnconfigure(0, weight=1)
        self._settings_section("notify")

    def _settings_section(self, key):
        for k, b in self.settings_nav.items():
            active = k == key
            b.configure(fg_color=COLORS["primary_soft"] if active else "transparent",
                        text_color=COLORS["primary"] if active else COLORS["text_secondary"],
                        hover_color=COLORS["primary_soft"] if active else COLORS["surface_alt"])
        _clear(self.settings_host)
        builder = {
            "basic": self._settings_basic,
            "notify": self._settings_notify,
            "users": self._settings_users,
            "audit": self._settings_audit,
            "about": self._settings_about,
        }.get(key, self._settings_notify)
        card = Card(self.settings_host, padding=17)
        card.grid(row=0, column=0, sticky="nsew")
        builder(card.body)

    def _settings_notify(self, b):
        head = ctk.CTkFrame(b, fg_color="transparent")
        head.pack(fill="x")
        box = ctk.CTkFrame(head, fg_color="transparent")
        box.pack(side="left")
        ctk.CTkLabel(box, text="通知渠道", font=F(15, "bold"), text_color=COLORS["text"], anchor="w").pack(anchor="w")
        ctk.CTkLabel(box, text="配置异常告警与巡检结果的通知送达方式", font=F(9.2), text_color=COLORS["text_muted"],
                     anchor="w").pack(anchor="w", pady=(2, 0))
        action_button(head, "发送测试消息", lambda: self.toast.show("测试消息已发送至企业微信"), "secondary", "mail",
                      108, 33).pack(side="right")

        channels = ctk.CTkFrame(b, fg_color="transparent")
        channels.pack(fill="x", pady=(12, 8))
        for i in range(2):
            channels.grid_columnconfigure(i, weight=1, uniform="ch")
        data = [
            ("企业微信", "已连接 · 运维告警群", "wechat", True, "#16A34A", "#E9F8EF"),
            ("邮件通知", "smtp.example.com · 3 个收件组", "mail", True, "#2563EB", "#EAF1FF"),
            ("短信通知", "仅用于严重级别告警", "monitor", False, "#D97706", "#FFF5E5"),
            ("Webhook", "对接内部事件中心", "webhook", False, "#7C3AED", "#F1EBFF"),
        ]
        for idx, (name, desc, ic, enabled, color, soft) in enumerate(data):
            c = ctk.CTkFrame(channels, fg_color=COLORS["surface"], border_width=1, border_color=COLORS["border"],
                             corner_radius=9, height=86)
            c.grid(row=idx // 2, column=idx % 2, sticky="ew", padx=(0 if idx % 2 == 0 else 6, 0),
                   pady=(0, 6))
            c.grid_propagate(False)
            chip = ctk.CTkFrame(c, width=32, height=32, corner_radius=8, fg_color=soft)
            chip.pack(side="left", padx=(11, 8))
            chip.pack_propagate(False)
            ctk.CTkLabel(chip, text="", image=icon(ic, color, 16)).pack(expand=True)
            body = ctk.CTkFrame(c, fg_color="transparent")
            body.pack(side="left", fill="both", expand=True, pady=13)
            ctk.CTkLabel(body, text=name, font=F(9.8, "bold"), text_color=COLORS["text"], anchor="w").pack(anchor="w")
            ctk.CTkLabel(body, text=desc, font=F(8.2), text_color=COLORS["text_muted"], anchor="w").pack(anchor="w")
            sw = ctk.CTkSwitch(c, text="", width=38, height=20, switch_width=36, switch_height=20,
                               progress_color=COLORS["primary"], fg_color=COLORS["border_strong"],
                               button_color="#FFFFFF", command=lambda n=name: self.toast.show(f"{n} 通知设置已更新"))
            sw.pack(side="right", padx=11)
            (sw.select if enabled else sw.deselect)()
            ctk.CTkButton(c, text="配置", width=34, height=24, fg_color="transparent",
                          hover_color=COLORS["primary_soft"], text_color=COLORS["primary"], font=F(8.7, "bold"),
                          command=lambda n=name: self.toast.show(f"已打开 {n} 配置", "warning")).pack(
                side="right", padx=(0, 1))

        policy = ctk.CTkFrame(b, fg_color="transparent")
        policy.pack(fill="both", expand=True)
        ph = ctk.CTkFrame(policy, fg_color="transparent")
        ph.pack(fill="x", pady=(7, 2))
        ctk.CTkLabel(ph, text="通知策略", font=F(12, "bold"), text_color=COLORS["text"]).pack(side="left")
        ctk.CTkLabel(ph, text="按级别与时间窗口控制通知频率", font=F(8.5), text_color=COLORS["text_muted"]).pack(
            side="left", padx=(8, 0))
        for label, desc, selected in [
            ("严重异常立即通知", "不受静默时段限制，通知值班负责人及上级", True),
            ("高危异常 5 分钟聚合", "同一服务器 5 分钟内的同类异常合并为一条", True),
            ("每日 09:00 发送巡检摘要", "汇总昨日任务、异常与健康度变化", True),
            ("仅工作日发送非紧急通知", "周末及法定节假日仅发送严重级别通知", False),
        ]:
            row = ctk.CTkFrame(policy, fg_color=COLORS["surface_alt"], corner_radius=7, height=50)
            row.pack(fill="x", pady=3)
            row.pack_propagate(False)
            b2 = ctk.CTkFrame(row, fg_color="transparent")
            b2.pack(side="left", padx=11, pady=6)
            ctk.CTkLabel(b2, text=label, font=F(9.2, "bold"), text_color=COLORS["text"], anchor="w").pack(anchor="w")
            ctk.CTkLabel(b2, text=desc, font=F(7.8), text_color=COLORS["text_muted"], anchor="w").pack(anchor="w")
            sw = ctk.CTkSwitch(row, text="", width=38, height=20, switch_width=36, switch_height=20,
                               progress_color=COLORS["primary"], fg_color=COLORS["border_strong"],
                               button_color="#FFFFFF")
            sw.pack(side="right", padx=12)
            (sw.select if selected else sw.deselect)()

        recent = ctk.CTkFrame(b, fg_color="transparent")
        recent.pack(fill="x", pady=(12, 0))
        rh = ctk.CTkFrame(recent, fg_color="transparent")
        rh.pack(fill="x", pady=(0, 4))
        ctk.CTkLabel(rh, text="最近通知记录", font=F(10.8, "bold"), text_color=COLORS["text"]).pack(side="left")
        ctk.CTkLabel(rh, text="过去 24 小时送达 38 条", font=F(8.2), text_color=COLORS["text_muted"]).pack(
            side="right")
        for tm, channel, target, result in [("10:42", "企业微信", "运维告警群 · 4 人", "已送达"),
                                            ("09:36", "邮件", "dba-team@example.com", "已送达")]:
            row = ctk.CTkFrame(recent, fg_color=COLORS["surface_alt"], corner_radius=6, height=28)
            row.pack(fill="x", pady=(0, 3))
            row.pack_propagate(False)
            ctk.CTkLabel(row, text=tm, font=("Consolas", 8.0), text_color=COLORS["text_muted"], width=44).pack(
                side="left", padx=(8, 0))
            ctk.CTkLabel(row, text=channel, font=F(8.2, "bold"), text_color=COLORS["text"], width=62).pack(
                side="left", padx=(4, 0))
            ctk.CTkLabel(row, text=target, font=F(8.2), text_color=COLORS["text_secondary"], anchor="w").pack(
                side="left", fill="x", expand=True)
            Pill(row, result, "#16A34A", "#E9F8EF", size=7.4).pack(side="right", padx=(4, 8))

    def _settings_basic(self, b):
        ctk.CTkLabel(b, text="基础设置", font=F(15, "bold"), text_color=COLORS["text"], anchor="w").pack(fill="x")
        ctk.CTkLabel(b, text="配置平台名称、数据保留与巡检引擎参数", font=F(9.2), text_color=COLORS["text_muted"],
                     anchor="w").pack(fill="x", pady=(2, 12))
        form = ctk.CTkFrame(b, fg_color="transparent")
        form.pack(fill="x")
        form.grid_columnconfigure(1, weight=1)
        fields = [("系统名称", "服务器巡检管理平台"), ("企业名称", "智维科技有限公司"),
                  ("服务地址", "https://inspect.example.com"), ("数据保留周期", "180 天")]
        for i, (lab, val) in enumerate(fields):
            ctk.CTkLabel(form, text=lab, font=F(9.2), text_color=COLORS["text_secondary"], anchor="w").grid(
                row=i, column=0, sticky="w", pady=7, padx=(0, 18))
            e = ctk.CTkEntry(form, height=34, fg_color=COLORS["surface_alt"], border_width=1,
                             border_color=COLORS["border"], corner_radius=7, font=F(9.6), text_color=COLORS["text"])
            e.grid(row=i, column=1, sticky="ew", pady=7)
            e.insert(0, val)
        ctk.CTkLabel(b, text="巡检引擎", font=F(11.5, "bold"), text_color=COLORS["text"], anchor="w").pack(
            fill="x", pady=(17, 6))
        for label, desc, val in [("最大并发执行数", "同时执行的巡检任务数量", "20"),
                                 ("单机采集超时", "超时后标记为失败并重试一次", "30 秒")]:
            row = ctk.CTkFrame(b, fg_color=COLORS["surface_alt"], corner_radius=7, height=40)
            row.pack(fill="x", pady=3)
            row.pack_propagate(False)
            ctk.CTkLabel(row, text=label, font=F(9.1, "bold"), text_color=COLORS["text"]).pack(side="left", padx=11)
            ctk.CTkLabel(row, text=desc, font=F(7.9), text_color=COLORS["text_muted"]).pack(side="left", padx=7)
            ctk.CTkLabel(row, text=val, font=F(9.2, "bold"), text_color=COLORS["primary"]).pack(side="right", padx=12)
        action_button(b, "保存设置", lambda: self.toast.show("基础设置已保存"), "primary", "check", 96, 34).pack(
            anchor="e", pady=(14, 0))

    def _settings_users(self, b):
        ctk.CTkLabel(b, text="用户与角色", font=F(15, "bold"), text_color=COLORS["text"], anchor="w").pack(fill="x")
        ctk.CTkLabel(b, text="当前共 6 名成员，按最小权限原则分配角色", font=F(9.2),
                     text_color=COLORS["text_muted"], anchor="w").pack(fill="x", pady=(2, 10))
        rows = [
            {"name": "李明", "account": "admin", "role": "超级管理员", "status": "启用", "last": "今天 09:41"},
            {"name": "张伟", "account": "zhangwei", "role": "运维工程师", "status": "启用", "last": "今天 09:36"},
            {"name": "陈晨", "account": "chenchen", "role": "数据库管理员", "status": "启用", "last": "今天 09:31"},
            {"name": "赵敏", "account": "zhaomin", "role": "只读观察员", "status": "启用", "last": "昨天 18:12"},
        ]
        cols = [
            {"key": "name", "title": "姓名", "width": 90, "type": "text", "color": COLORS["text"], "weight": "bold"},
            {"key": "account", "title": "账号", "width": 110, "type": "mono", "size": 9.2},
            {"key": "role", "title": "角色", "width": 120, "type": "text"},
            {"key": "status", "title": "状态", "width": 65, "type": "status"},
            {"key": "last", "title": "最近登录", "width": 100, "type": "text", "size": 9},
        ]
        DataTable(b, cols, rows, row_height=42, footer="共 6 名成员").pack(fill="both", expand=True, pady=(4, 0))

    def _settings_audit(self, b):
        ctk.CTkLabel(b, text="审计日志", font=F(15, "bold"), text_color=COLORS["text"], anchor="w").pack(fill="x")
        ctk.CTkLabel(b, text="记录登录、配置变更、任务操作与数据导出行为", font=F(9.2),
                     text_color=COLORS["text_muted"], anchor="w").pack(fill="x", pady=(2, 10))
        rows = [{"time": t, "user": u, "action": a, "detail": d, "ip": ip} for t, u, a, d, ip in AUDIT_LOGS]
        cols = [
            {"key": "time", "title": "时间", "width": 128, "type": "mono", "size": 8.4},
            {"key": "user", "title": "操作人", "width": 70, "type": "text"},
            {"key": "action", "title": "操作", "width": 110, "type": "text", "color": COLORS["text"]},
            {"key": "detail", "title": "对象 / 详情", "width": 240, "type": "text", "size": 8.9},
            {"key": "ip", "title": "来源 IP", "width": 90, "type": "mono", "size": 8.5},
        ]
        DataTable(b, cols, rows, row_height=40, footer="显示最近 6 条  ·  日志保留 180 天").pack(
            fill="both", expand=True, pady=(4, 0))

    def _settings_about(self, b):
        ctk.CTkLabel(b, text="关于系统", font=F(15, "bold"), text_color=COLORS["text"], anchor="w").pack(fill="x")
        ctk.CTkLabel(b, text="", image=logo_image(64), width=64).pack(anchor="w", pady=(18, 10))
        ctk.CTkLabel(b, text=BRAND["product"], font=F(18, "bold"), text_color=COLORS["text"], anchor="w").pack(fill="x")
        ctk.CTkLabel(b, text=f"版本 {BRAND['version']}  ·  Build {BRAND['build']}", font=F(9.5),
                     text_color=COLORS["text_muted"], anchor="w").pack(fill="x", pady=(2, 12))
        for k, v in [("授权状态", "演示授权 · 不限服务器数量"), ("技术支持", "support@zhiwei.example.com"),
                     ("产品文档", "docs.zhiwei.example.com/inspection"), ("开源组件", "CustomTkinter 5.2.2 / Pillow 12.3")]:
            row = ctk.CTkFrame(b, fg_color=COLORS["surface_alt"], corner_radius=7, height=38)
            row.pack(fill="x", pady=3)
            row.pack_propagate(False)
            ctk.CTkLabel(row, text=k, font=F(8.8), text_color=COLORS["text_muted"]).pack(side="left", padx=11)
            ctk.CTkLabel(row, text=v, font=F(9.1, "bold"), text_color=COLORS["text"]).pack(side="right", padx=11)

    # ---------------------------------------------------------------- detail pages
    def _make_detail_frame(self, key):
        f = ctk.CTkFrame(self.page_host, fg_color=COLORS["bg"], corner_radius=0)
        f.grid(row=0, column=0, sticky="nsew", padx=20, pady=15)
        f.grid_remove()
        self.detail_frames[key] = f
        return f

    def _build_task_detail(self):
        self.task_detail_frame = self._make_detail_frame("task_detail")

    def show_task_detail(self, task):
        f = self.task_detail_frame
        _clear(f)
        self._stop_live()
        self._show_detail("task_detail", "tasks")
        f.grid_rowconfigure(3, weight=1)
        f.grid_columnconfigure(0, weight=1)
        back = ctk.CTkFrame(f, fg_color="transparent", height=44)
        back.grid(row=0, column=0, sticky="ew")
        b = ctk.CTkButton(back, text="返回任务列表", image=icon("back", COLORS["text_secondary"], 15),
                          compound="left", fg_color="transparent", hover_color=COLORS["surface_alt"],
                          text_color=COLORS["text_secondary"], font=F(9.8), width=106, height=28,
                          command=lambda: self.show_page("tasks"))
        b.pack(side="left")
        ctk.CTkLabel(back, text="/", font=F(10), text_color=COLORS["border_strong"]).pack(side="left", padx=4)
        ctk.CTkLabel(back, text="任务详情", font=F(9.8), text_color=COLORS["text_muted"]).pack(side="left")
        action_button(back, "导出日志", lambda: self.toast.show("任务日志已导出"), "secondary", "download", 88, 30).pack(
            side="right")
        action_button(back, "终止任务", lambda: self._terminate_task(task), "danger", "close", 84, 30).pack(
            side="right", padx=(0, 6))

        title = ctk.CTkFrame(f, fg_color="transparent")
        title.grid(row=1, column=0, sticky="ew", pady=(2, 9))
        title.grid_columnconfigure(0, weight=1)
        box = ctk.CTkFrame(title, fg_color="transparent")
        box.grid(row=0, column=0, sticky="w")
        line = ctk.CTkFrame(box, fg_color="transparent")
        line.pack(anchor="w")
        ctk.CTkLabel(line, text=task["name"], font=F(18, "bold"), text_color=COLORS["text"]).pack(side="left")
        status_pill = Pill(line, task["status"], *status_palette(task["status"]), size=9)
        status_pill.pack(side="left", padx=(9, 0))
        ctk.CTkLabel(box, text=f"{task['id']}  ·  {task['scope']}  ·  开始于 {task['start']}", font=F(8.9),
                     text_color=COLORS["text_muted"], anchor="w").pack(anchor="w", pady=(3, 0))
        progress = [t for t in TASKS if t["id"] == task["id"]]
        pct = int(progress[0]["progress"]) if progress else int(task.get("progress", 0))
        self._detail_task = task
        self._detail_status_pill = status_pill
        self._detail_pct_label = ctk.CTkLabel(title, text=f"{pct}%", font=F(24, "bold"),
                                              text_color=COLORS["text"])
        self._detail_pct_label.grid(row=0, column=1, sticky="e", padx=(0, 4))
        ctk.CTkLabel(title, text="完成度", font=F(8.5), text_color=COLORS["text_muted"]).grid(row=0, column=2,
                                                                                            sticky="e", pady=(8, 0))

        summary = Card(f, padding=12)
        summary.grid(row=2, column=0, sticky="ew")
        sb = summary.body
        for i in range(6):
            sb.grid_columnconfigure(i, weight=1, uniform="sum")
        ring = charts.progress_ring(pct, 66)
        self._detail_ring_label = self._image_label(sb, ring, (66, 66))
        self._detail_ring_label.grid(row=0, column=0, rowspan=2, padx=(0, 4))
        summary_data = [
            ("巡检对象", "8 台服务器", "生产核心组"),
            ("检查项", f"{task.get('items', 208)} 项", "26 项 / 台"),
            ("已通过", f"{task.get('passed', 166)} 项", "通过率 79.8%"),
            ("发现异常", f"{task.get('abnormal', 4)} 项", "严重 1 · 高危 2"),
            ("已用时", task.get("elapsed", "12 分 36 秒"), "预计剩余 5 分钟"),
        ]
        for i, (lab, val, note) in enumerate(summary_data, start=1):
            box = ctk.CTkFrame(sb, fg_color="transparent")
            box.grid(row=0, column=i, rowspan=2, sticky="w", padx=(8, 0))
            ctk.CTkLabel(box, text=lab, font=F(8.2), text_color=COLORS["text_muted"], anchor="w").pack(anchor="w")
            ctk.CTkLabel(box, text=val, font=F(11.3, "bold"), text_color=COLORS["text"], anchor="w").pack(anchor="w",
                                                                                                        pady=(2, 0))
            ctk.CTkLabel(box, text=note, font=F(7.7), text_color=COLORS["text_muted"], anchor="w").pack(anchor="w")
        action_button(sb, f"查看 {task.get('abnormal', 4)} 项异常", lambda: self.show_issue_detail(ISSUES[0]),
                      "secondary", "issue", 112, 30).grid(row=0, column=6, rowspan=2, padx=(4, 0))

        content = ctk.CTkFrame(f, fg_color="transparent")
        content.grid(row=3, column=0, sticky="nsew", pady=(9, 0))
        content.grid_columnconfigure(0, weight=67, uniform="td")
        content.grid_columnconfigure(1, weight=33, uniform="td")
        content.grid_rowconfigure(0, weight=1)

        left = ctk.CTkFrame(content, fg_color="transparent")
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        left.grid_rowconfigure(1, weight=1)
        left.grid_columnconfigure(0, weight=1)
        overview = Card(left, padding=13)
        overview.grid(row=0, column=0, sticky="ew")
        ob = overview.body
        oh = ctk.CTkFrame(ob, fg_color="transparent")
        oh.pack(fill="x")
        ctk.CTkLabel(oh, text="执行概览", font=F(11.5, "bold"), text_color=COLORS["text"]).pack(side="left")
        self._detail_note = ctk.CTkLabel(oh, text=f"任务已执行 {pct}%  ·  预计 10:17 完成", font=F(8.3),
                                         text_color=COLORS["text_muted"])
        self._detail_note.pack(side="right")
        self._detail_bar = ctk.CTkProgressBar(ob, height=8, corner_radius=4, fg_color=COLORS["track"],
                                              progress_color=COLORS["primary"])
        self._detail_bar.pack(fill="x", pady=(8, 7))
        self._detail_bar.set(pct / 100)
        stats = ctk.CTkFrame(ob, fg_color="transparent")
        stats.pack(fill="x")
        abn = task.get("abnormal", 4)
        pending = task.get("pending", 38)
        for i, (lab, val, color) in enumerate([("检查项", str(task.get("items", 208)), COLORS["text"]),
                                                ("已通过", str(task.get("passed", 166)), COLORS["success"]),
                                                ("异常", str(abn), COLORS["danger"]),
                                                ("待检查", str(pending), COLORS["text_muted"])]):
            stats.grid_columnconfigure(i, weight=1)
            box = ctk.CTkFrame(stats, fg_color="transparent")
            box.grid(row=0, column=i, sticky="w")
            ctk.CTkLabel(box, text=val, font=F(14, "bold"), text_color=color).pack(side="left")
            ctk.CTkLabel(box, text=lab, font=F(8.2), text_color=COLORS["text_muted"]).pack(side="left", padx=(4, 0),
                                                                                           pady=(3, 0))

        log_card = Card(left, padding=0, fg_color="#0B1524", border_color="#17283E")
        log_card.grid(row=1, column=0, sticky="nsew", pady=(9, 0))
        lb = ctk.CTkFrame(log_card.body, fg_color="#0B1524", corner_radius=10)
        lb.pack(fill="both", expand=True, padx=14, pady=12)
        lh = ctk.CTkFrame(lb, fg_color="transparent")
        lh.pack(fill="x")
        ctk.CTkLabel(lh, text="实时执行日志", font=F(10.8, "bold"), text_color="#E7EEF8").pack(side="left")
        live = ctk.CTkLabel(lh, text="  LIVE  ", font=("Consolas", 8, "bold"), text_color="#6EE7B7",
                            fg_color="#12372A", corner_radius=6, height=18)
        live.pack(side="left", padx=(8, 0))
        ctk.CTkLabel(lh, text="自动滚动", font=F(8.1), text_color="#71859D").pack(side="right")
        ctk.CTkSwitch(lh, text="", width=32, height=16, switch_width=30, switch_height=16,
                      progress_color="#10B981", fg_color="#334155", button_color="#FFFFFF").pack(side="right",
                                                                                               padx=(0, 5))
        log_text = ctk.CTkTextbox(lb, fg_color="#0B1524", text_color="#AEBED1", font=("Consolas", 9.2),
                                  border_width=0, wrap="none", height=150)
        log_text.pack(fill="both", expand=True, pady=(8, 0))
        log_text.tag_config("INFO", foreground="#7DD3FC")
        log_text.tag_config("WARN", foreground="#FCD34D")
        log_text.tag_config("ERR", foreground="#FCA5A5")
        log_text.tag_config("time", foreground="#64748B")
        log_text.tag_config("server", foreground="#94A3B8")
        for tm, level, server, msg in TASK_LOGS:
            log_text.insert("end", tm + "  ", "time")
            log_text.insert("end", f"{level:<5}", level)
            log_text.insert("end", f"[{server}]  ", "server")
            log_text.insert("end", msg + "\n")
        log_text.configure(state="disabled")

        right = Card(content, padding=13)
        right.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        rb = right.body
        rh = ctk.CTkFrame(rb, fg_color="transparent")
        rh.pack(fill="x")
        ctk.CTkLabel(rh, text="巡检对象", font=F(11.5, "bold"), text_color=COLORS["text"]).pack(side="left")
        ctk.CTkLabel(rh, text="8 台", font=F(8.5), text_color=COLORS["text_muted"]).pack(side="right")
        for s in TASK_SERVERS:
            row = ctk.CTkFrame(rb, fg_color=COLORS["surface_alt"] if s["status"] != "排队中" else COLORS["surface"],
                               corner_radius=7, height=45)
            row.pack(fill="x", pady=(4, 0))
            row.pack_propagate(False)
            b = ctk.CTkFrame(row, fg_color="transparent")
            b.pack(side="left", padx=9, pady=3)
            ctk.CTkLabel(b, text=s["name"], font=F(8.8, "bold"), text_color=COLORS["text"], anchor="w").pack(anchor="w")
            ctk.CTkLabel(b, text=s["ip"], font=("Consolas", 7.7), text_color=COLORS["text_muted"],
                         anchor="w").pack(anchor="w")
            bar = ctk.CTkProgressBar(row, height=4, width=68, corner_radius=2, fg_color=COLORS["track"],
                                     progress_color=COLORS["primary"] if s["status"] == "执行中" else COLORS["success"]
                                     if s["progress"] == 100 else COLORS["border_strong"])
            bar.pack(side="right", padx=(0, 3))
            bar.set(s["progress"] / 100)
            ctk.CTkLabel(row, text=f"{s['progress']}%" if s["progress"] else "—", font=F(7.6, "bold"),
                         text_color=COLORS["text_muted"], width=27).pack(side="right")
            if s["issues"]:
                ctk.CTkLabel(row, text=f"{s['issues']} 异常", font=F(7.4, "bold"), text_color=COLORS["danger"]).pack(
                    side="right", padx=(2, 5))
        ctk.CTkFrame(rb, fg_color=COLORS["border"], height=1).pack(fill="x", pady=(8, 4))
        ctk.CTkLabel(rb, text="采集器版本 2.6.1  ·  心跳正常", font=F(7.8), text_color=COLORS["text_muted"],
                     anchor="w").pack(fill="x")
        if self.capture_mode or pct >= 100:
            return
        self._live_job = self.after(1200, lambda: self._tick_task(task, pct, log_text))

    def _tick_task(self, task, pct, log_text):
        if self._current_page != "task_detail":
            return
        pct = min(100, int(task.get("progress", 0)) + 4)
        task["progress"] = pct
        try:
            self._detail_pct_label.configure(text=f"{pct}%")
            self._detail_bar.set(pct / 100)
            self._detail_note.configure(text=f"任务已执行 {pct}%  ·  预计 10:17 完成")
            ring = charts.progress_ring(pct, 66)
            ci = ctk.CTkImage(light_image=ring, dark_image=ring, size=(66, 66))
            self._image_refs.append(ci)
            self._detail_ring_label.configure(image=ci)
        except Exception:
            return
        if pct >= 100:
            task["status"] = "已完成"
            try:
                self._detail_status_pill.configure(text=" 已完成 ", fg_color=COLORS["success_soft"],
                                                   text_color=COLORS["success"])
                self._detail_note.configure(text="任务已完成  ·  共发现 4 项异常  ·  报告已归档")
            except Exception:
                pass
            self._live_job = None
            self.toast.show(f"任务 {task['id']} 已完成，共发现 4 项异常")
            return
        self._live_job = self.after(900, lambda: self._tick_task(task, pct, log_text))

    def _terminate_task(self, task):
        task["status"] = "失败"
        self.toast.show(f"任务 {task['id']} 已终止", "warning")
        self.show_page("tasks")

    def _build_issue_detail(self):
        self.issue_detail_frame = self._make_detail_frame("issue_detail")

    def show_issue_detail(self, issue):
        f = self.issue_detail_frame
        _clear(f)
        self._stop_live()
        self._show_detail("issue_detail", "issues")
        f.grid_rowconfigure(2, weight=1)
        f.grid_columnconfigure(0, weight=1)
        back = ctk.CTkFrame(f, fg_color="transparent", height=42)
        back.grid(row=0, column=0, sticky="ew")
        ctk.CTkButton(back, text="返回工单列表", image=icon("back", COLORS["text_secondary"], 15), compound="left",
                      fg_color="transparent", hover_color=COLORS["surface_alt"], text_color=COLORS["text_secondary"],
                      font=F(9.8), width=106, height=28, command=lambda: self.show_page("issues")).pack(side="left")
        ctk.CTkLabel(back, text="/", font=F(10), text_color=COLORS["border_strong"]).pack(side="left", padx=4)
        ctk.CTkLabel(back, text=issue["id"], font=("Consolas", 9.2), text_color=COLORS["text_muted"]).pack(side="left")
        action_button(back, "更多操作", lambda: self.toast.show("更多操作：转派、升级、关联知识库", "warning"),
                      "secondary", "dots", 88, 30).pack(side="right")

        hero = Card(f, padding=15)
        hero.grid(row=1, column=0, sticky="ew", pady=(2, 9))
        hb = hero.body
        hb.grid_columnconfigure(1, weight=1)
        fg, bg = level_palette(issue["level"])
        ctk.CTkLabel(hb, text=issue["level"], width=44, height=44, corner_radius=10, fg_color=bg,
                     text_color=fg, font=F(11, "bold")).grid(row=0, column=0, rowspan=2, padx=(0, 11))
        ctk.CTkLabel(hb, text=issue["title"], font=F(18, "bold"), text_color=COLORS["text"], anchor="w").grid(
            row=0, column=1, sticky="w")
        meta = ctk.CTkFrame(hb, fg_color="transparent")
        meta.grid(row=1, column=1, sticky="w", pady=(3, 0))
        for text in [issue["id"], issue["server"], issue["type"], f"来源：{issue['source']}"]:
            ctk.CTkLabel(meta, text=text, font=F(8.6), text_color=COLORS["text_muted"]).pack(side="left", padx=(0, 12))
        right = ctk.CTkFrame(hb, fg_color="transparent")
        right.grid(row=0, column=2, rowspan=2, sticky="e")
        Pill(right, issue["status"], *status_palette(issue["status"]), size=9).pack(anchor="e")
        ctk.CTkLabel(right, text=f"SLA {issue['sla']}", font=F(8.8, "bold"), text_color=COLORS["danger"]).pack(
            anchor="e", pady=(4, 0))
        action_button(right, "标记闭环", lambda: self._close_issue(issue), "primary", "check", 88, 31).pack(
            anchor="e", pady=(5, 0))

        content = ctk.CTkFrame(f, fg_color="transparent")
        content.grid(row=2, column=0, sticky="nsew")
        content.grid_columnconfigure(0, weight=65, uniform="id")
        content.grid_columnconfigure(1, weight=35, uniform="id")
        content.grid_rowconfigure(0, weight=1)

        left = Card(content, padding=16)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        lb = left.body
        lh = ctk.CTkFrame(lb, fg_color="transparent")
        lh.pack(fill="x")
        ctk.CTkLabel(lh, text="处置时间线", font=F(12, "bold"), text_color=COLORS["text"]).pack(side="left")
        ctk.CTkLabel(lh, text="工单创建至今 32 分钟", font=F(8.4), text_color=COLORS["text_muted"]).pack(
            side="right")
        timeline = ctk.CTkFrame(lb, fg_color="transparent")
        timeline.pack(fill="both", expand=True, pady=(12, 0))
        for i, (tm, who, act, note, ic) in enumerate(ISSUE_TIMELINE):
            row = ctk.CTkFrame(timeline, fg_color="transparent")
            row.pack(fill="x", pady=(0, 4))
            marker = ctk.CTkFrame(row, width=28, height=28, corner_radius=14,
                                  fg_color=COLORS["primary_soft"] if i < 4 else COLORS["warning_soft"])
            marker.pack(side="left", anchor="n", padx=(0, 10))
            marker.pack_propagate(False)
            ctk.CTkLabel(marker, text="", image=icon(ic, COLORS["primary"] if i < 4 else COLORS["warning"], 14)).pack(
                expand=True)
            box = ctk.CTkFrame(row, fg_color="transparent")
            box.pack(side="left", fill="x", expand=True)
            line = ctk.CTkFrame(box, fg_color="transparent")
            line.pack(fill="x")
            ctk.CTkLabel(line, text=act, font=F(9.5, "bold"), text_color=COLORS["text"], anchor="w").pack(side="left")
            ctk.CTkLabel(line, text=f"{who}  ·  {tm}", font=F(8.0), text_color=COLORS["text_muted"]).pack(side="right")
            ctk.CTkLabel(box, text=note, font=F(8.4), text_color=COLORS["text_secondary"], anchor="w",
                         wraplength=430, justify="left").pack(fill="x", pady=(2, 0))
            if i < len(ISSUE_TIMELINE) - 1:
                ctk.CTkFrame(timeline, width=1, height=12, fg_color=COLORS["border"]).pack(anchor="w", padx=(13, 0))
        input_box = ctk.CTkFrame(lb, fg_color=COLORS["surface_alt"], corner_radius=8)
        input_box.pack(fill="x", pady=(8, 0))
        ctk.CTkEntry(input_box, placeholder_text="补充处置记录，支持 @ 提及协作者…", height=34, border_width=0,
                     fg_color="transparent", font=F(9.2), text_color=COLORS["text"]).pack(side="left", fill="x",
                                                                                          expand=True, padx=8)
        action_button(input_box, "提交", lambda: self.toast.show("处置记录已提交"), "primary", None, 56, 28).pack(
            side="right", padx=5, pady=4)

        right = ctk.CTkFrame(content, fg_color="transparent")
        right.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        right.grid_rowconfigure(0, weight=1)
        right.grid_rowconfigure(1, weight=1)
        assess = Card(right, padding=14)
        assess.grid(row=0, column=0, sticky="nsew", pady=(0, 6))
        ab = assess.body
        ctk.CTkLabel(ab, text="影响评估", font=F(11.5, "bold"), text_color=COLORS["text"], anchor="w").pack(fill="x")
        ctk.CTkLabel(ab, text=issue["detail"], font=F(8.8), text_color=COLORS["text_secondary"], anchor="w",
                     wraplength=310, justify="left").pack(fill="x", pady=(5, 8))
        for name, val, color in [("磁盘使用率", 92, COLORS["danger"]), ("CPU 使用率", 71, COLORS["warning"]),
                                 ("内存使用率", 83, COLORS["warning"])]:
            row = ctk.CTkFrame(ab, fg_color="transparent")
            row.pack(fill="x", pady=2)
            ctk.CTkLabel(row, text=name, font=F(8.2), text_color=COLORS["text_muted"], width=76).pack(side="left")
            bar = ctk.CTkProgressBar(row, height=6, corner_radius=3, fg_color=COLORS["track"], progress_color=color)
            bar.pack(side="left", fill="x", expand=True, padx=(2, 6))
            bar.set(val / 100)
            ctk.CTkLabel(row, text=f"{val}%", font=F(8.2, "bold"), text_color=color, width=28).pack(side="right")
        ctk.CTkLabel(ab, text="负责人  张伟   ·   SLA 剩余 1 小时 20 分", font=F(8.3),
                     text_color=COLORS["text_muted"], anchor="w").pack(fill="x", pady=(8, 0))

        advice = Card(right, padding=14)
        advice.grid(row=1, column=0, sticky="nsew", pady=(6, 0))
        adb = advice.body
        ctk.CTkLabel(adb, text="处置建议", font=F(11.5, "bold"), text_color=COLORS["text"], anchor="w").pack(fill="x")
        ctk.CTkLabel(adb, text="根据历史相似工单与知识库推荐", font=F(8.2), text_color=COLORS["text_muted"],
                     anchor="w").pack(fill="x", pady=(1, 6))
        for i, text in enumerate(["确认 /var/lib/mysql 下 binlog 保留策略",
                                  "清理 7 天前的 binlog 并验证主从同步",
                                  "扩容数据盘 200 GB，更新容量基线",
                                  "复核后关闭工单并补充巡检规则"]):
            row = ctk.CTkFrame(adb, fg_color="transparent")
            row.pack(fill="x", pady=2)
            ctk.CTkLabel(row, text=str(i + 1), width=18, height=18, corner_radius=9, fg_color=COLORS["primary_soft"],
                         text_color=COLORS["primary"], font=F(7.8, "bold")).pack(side="left", padx=(0, 7))
            ctk.CTkLabel(row, text=text, font=F(8.4), text_color=COLORS["text_secondary"], anchor="w",
                         wraplength=290, justify="left").pack(side="left", fill="x", expand=True)
        ctk.CTkFrame(adb, fg_color=COLORS["border"], height=1).pack(fill="x", pady=7)
        ctk.CTkLabel(adb, text="关联知识库  KB-0042  数据库磁盘空间治理", font=F(8.2, "bold"),
                     text_color=COLORS["primary"], anchor="w").pack(fill="x")

    def _close_issue(self, issue):
        issue["status"] = "已闭环"
        self.toast.show(f"{issue['id']} 已标记为闭环")
        self.show_page("issues")

    # ---------------------------------------------------------------- dialogs
    def _open_inspection_dialog(self):
        InspectionDialog(self)

    def _open_add_server(self):
        AddServerDialog(self, self._add_server)

    def _add_server(self, data):
        SERVERS.insert(0, data)
        self.server_total = getattr(self, "server_total", 48) + 1
        self._render_server_table(SERVERS)
        self.server_count_label.configure(text=f"共 {self.server_total} 台  ·  在线 {self.server_total - 1}  ·  待关注 7")
        self.toast.show(f"服务器 {data['name']} 已添加")

    def _open_server_detail(self, server):
        ServerDetailDialog(self, server, self)

    def start_inspection(self):
        task = copy.deepcopy(TASKS[0])
        task["id"] = "TASK-20261028-0043"
        task["start"] = "2026-10-28 10:45"
        task["progress"] = 0
        task["status"] = "执行中"
        self.show_task_detail(task)
        self.toast.show("巡检任务已下发，正在采集 8 台服务器")


class InspectionDialog(BaseDialog):
    def __init__(self, app):
        super().__init__(app, "发起巡检", 600, 488, "选择巡检范围与模板，立即下发采集任务")
        self.app = app
        b = self.content
        ctk.CTkLabel(b, text="巡检范围", font=F(9.2, "bold"), text_color=COLORS["text_secondary"], anchor="w").pack(
            fill="x")
        seg = ctk.CTkSegmentedButton(b, values=["按计划执行", "自定义范围"], height=34, corner_radius=7,
                                     selected_color=COLORS["primary"], selected_hover_color=COLORS["primary_hover"],
                                     unselected_color=COLORS["surface_alt"], unselected_hover_color=COLORS["primary_soft"],
                                     text_color=COLORS["text"], font=F(9.6))
        seg.pack(fill="x", pady=(5, 12))
        seg.set("按计划执行")
        for lab, vals in [("巡检计划", ["核心业务服务器日常巡检（8 台）", "数据库专项巡检（4 台）",
                                    "Web 应用健康检查（6 台）"]),
                          ("巡检模板", ["Linux 主机基础巡检（26 项）", "MySQL 数据库专项巡检（18 项）"])]:
            ctk.CTkLabel(b, text=lab, font=F(9.2, "bold"), text_color=COLORS["text_secondary"], anchor="w").pack(
                fill="x")
            menu = ctk.CTkOptionMenu(b, values=vals, height=36, corner_radius=8, fg_color=COLORS["surface_alt"],
                                     button_color=COLORS["surface_alt"], text_color=COLORS["text"],
                                     button_hover_color=COLORS["primary_soft"], dropdown_fg_color=COLORS["surface"],
                                     font=F(9.8), dropdown_font=F(9.6))
            menu.pack(fill="x", pady=(5, 12))
        row = ctk.CTkFrame(b, fg_color="transparent")
        row.pack(fill="x", pady=(0, 6))
        ctk.CTkLabel(row, text="执行方式", font=F(9.2, "bold"), text_color=COLORS["text_secondary"]).pack(side="left")
        mode = ctk.CTkSegmentedButton(row, values=["立即执行", "加入队列"], height=30, width=176, corner_radius=7,
                                      selected_color=COLORS["primary"], selected_hover_color=COLORS["primary_hover"],
                                      unselected_color=COLORS["surface_alt"], font=F(9))
        mode.pack(side="right")
        mode.set("立即执行")
        info = ctk.CTkFrame(b, fg_color=COLORS["primary_soft"], corner_radius=8, height=55)
        info.pack(fill="x", pady=(9, 0))
        info.pack_propagate(False)
        ctk.CTkLabel(info, text="预计耗时 8–12 分钟  ·  本次将检查 208 个指标项", font=F(8.8, "bold"),
                     text_color=COLORS["primary"]).pack(anchor="w", padx=12, pady=(8, 0))
        ctk.CTkLabel(info, text="完成后将通过企业微信发送结果摘要，严重异常自动创建工单。", font=F(8.0),
                     text_color=COLORS["text_secondary"]).pack(anchor="w", padx=12, pady=(1, 0))
        foot = ctk.CTkFrame(b, fg_color="transparent")
        foot.pack(fill="x", side="bottom", pady=(14, 0))
        action_button(foot, "取消", self.destroy, "secondary", None, 76, 34).pack(side="right")
        action_button(foot, "开始巡检", self._start, "primary", "play", 100, 34).pack(side="right", padx=(0, 8))

    def _start(self):
        self.destroy()
        self.app.after(80, self.app.start_inspection)


class AddServerDialog(BaseDialog):
    def __init__(self, app, callback):
        super().__init__(app, "新增服务器", 600, 535, "录入基础信息，保存后可立即发起巡检")
        self.app = app
        self.callback = callback
        b = self.content
        self.entries = {}
        fields = [("服务器名称", "例如 prod-web-03", "名称"), ("IP 地址", "10.20.8.13", "ip"),
                  ("机房 / 机柜", "A 机房 / A-03", "room"), ("操作系统", "Ubuntu 22.04 LTS", "os"),
                  ("业务分组", "电商前端", "group"), ("负责人", "李响", "owner")]
        form = ctk.CTkFrame(b, fg_color="transparent")
        form.pack(fill="x")
        form.grid_columnconfigure(1, weight=1)
        for i, (lab, ph, key) in enumerate(fields):
            ctk.CTkLabel(form, text=lab, font=F(9.0), text_color=COLORS["text_secondary"], anchor="w").grid(
                row=i, column=0, sticky="w", padx=(0, 12), pady=5)
            e = ctk.CTkEntry(form, placeholder_text=ph, height=34, fg_color=COLORS["surface_alt"], border_width=1,
                             border_color=COLORS["border"], corner_radius=7, font=F(9.4))
            e.grid(row=i, column=1, sticky="ew", pady=5)
            self.entries[key] = e
        tip = ctk.CTkFrame(b, fg_color=COLORS["surface_alt"], corner_radius=8, height=44)
        tip.pack(fill="x", pady=(9, 0))
        tip.pack_propagate(False)
        ctk.CTkLabel(tip, text="采集器需已安装并放通 8443 端口；保存后系统会自动进行连通性探测。", font=F(8.2),
                     text_color=COLORS["text_muted"]).pack(anchor="w", padx=11, pady=12)
        foot = ctk.CTkFrame(b, fg_color="transparent")
        foot.pack(fill="x", side="bottom", pady=(12, 0))
        action_button(foot, "取消", self.destroy, "secondary", None, 76, 34).pack(side="right")
        action_button(foot, "保存并探测", self._save, "primary", "check", 104, 34).pack(side="right", padx=(0, 8))

    def _save(self):
        name = self.entries["name"].get().strip()
        ip = self.entries["ip"].get().strip()
        if not name or not ip:
            self.app.toast.show("请填写服务器名称与 IP 地址", "warning")
            return
        data = {
            "name": name, "ip": ip, "room": self.entries["room"].get() or "未分配 / —",
            "os": self.entries["os"].get() or "Linux", "group": self.entries["group"].get() or "未分组",
            "health": 96, "status": "在线", "last": "尚未巡检", "cpu": 0, "mem": 0, "disk": 0,
            "uptime": "—", "owner": self.entries["owner"].get() or "未指派", "tags": ["新接入"],
        }
        self.destroy()
        self.callback(data)


class ServerDetailDialog(BaseDialog):
    def __init__(self, app, server, main_app):
        super().__init__(app, f"服务器详情 · {server['name']}", 780, 610, server["ip"])
        self.server = server
        self.app = main_app
        b = self.content
        top = ctk.CTkFrame(b, fg_color="transparent")
        top.pack(fill="x")
        left = ctk.CTkFrame(top, fg_color="transparent")
        left.pack(side="left")
        ctk.CTkLabel(left, text=server["name"], font=F(18, "bold"), text_color=COLORS["text"]).pack(side="left")
        Pill(left, server["status"], *status_palette(server["status"]), size=8.8).pack(side="left", padx=(8, 0))
        ctk.CTkLabel(left, text=f"  {server['ip']}", font=("Consolas", 9.2), text_color=COLORS["text_muted"]).pack(
            side="left", padx=(8, 0))
        for tag in server["tags"]:
            ctk.CTkLabel(left, text=f" {tag} ", font=F(7.6, "bold"), text_color=COLORS["primary"],
                         fg_color=COLORS["primary_soft"], corner_radius=6, height=18).pack(side="left", padx=(6, 0))
        ctk.CTkLabel(b, text=f"{server['room']}  ·  {server['os']}  ·  负责人 {server['owner']}", font=F(8.8),
                     text_color=COLORS["text_muted"], anchor="w").pack(fill="x", pady=(4, 10))

        metrics = ctk.CTkFrame(b, fg_color="transparent")
        metrics.pack(fill="x")
        for i, (lab, val, color) in enumerate([("CPU", server["cpu"], COLORS["primary"]),
                                               ("内存", server["mem"], COLORS["warning"]),
                                               ("磁盘", server["disk"], COLORS["danger"] if server["disk"] > 85
                                                else COLORS["success"]),
                                               ("健康度", server["health"], health_color(server["health"]))]):
            c = ctk.CTkFrame(metrics, fg_color=COLORS["surface_alt"], corner_radius=8, height=76)
            c.pack(side="left", fill="x", expand=True, padx=(0 if i == 0 else 6, 0))
            c.pack_propagate(False)
            ctk.CTkLabel(c, text=lab, font=F(8.2), text_color=COLORS["text_muted"]).pack(anchor="w", padx=10,
                                                                                         pady=(8, 0))
            ctk.CTkLabel(c, text=f"{val}%", font=F(16, "bold"), text_color=color).pack(anchor="w", padx=10)
            bar = ctk.CTkProgressBar(c, height=4, corner_radius=2, fg_color=COLORS["track"], progress_color=color)
            bar.pack(fill="x", padx=10, pady=(3, 7))
            bar.set(val / 100)

        info = ctk.CTkFrame(b, fg_color=COLORS["surface_alt"], corner_radius=9)
        info.pack(fill="x", pady=(10, 0))
        info.grid_columnconfigure(1, weight=1)
        info.grid_columnconfigure(3, weight=1)
        for i, (k, v) in enumerate([("资产编号", f"SRV-{server['name'][-2:].upper()}-0091"),
                                    ("业务分组", server["group"]), ("最近巡检", server["last"]),
                                    ("连续运行", server["uptime"]), ("采集器", "agent 2.6.1 · 在线"),
                                    ("资产标签", "、".join(server["tags"]))]):
            ctk.CTkLabel(info, text=k, font=F(8.2), text_color=COLORS["text_muted"]).grid(
                row=i // 2, column=(i % 2) * 2, sticky="w", padx=(11, 6), pady=5)
            ctk.CTkLabel(info, text=v, font=F(8.8, "bold"), text_color=COLORS["text"]).grid(
                row=i // 2, column=(i % 2) * 2 + 1, sticky="w", pady=5, padx=(0, 10))

        ctk.CTkLabel(b, text="最近巡检记录", font=F(11.2, "bold"), text_color=COLORS["text"], anchor="w").pack(
            fill="x", pady=(11, 2))
        rows = [
            {"time": "10-28 09:12", "task": "核心业务服务器日常巡检", "result": "2 项通过 · 0 异常", "status": "已完成"},
            {"time": "10-27 09:00", "task": "核心业务服务器日常巡检", "result": "26 项通过 · 0 异常", "status": "已完成"},
            {"time": "10-26 09:00", "task": "核心业务服务器日常巡检", "result": "1 项异常 · 已闭环", "status": "已完成"},
        ]
        cols = [
            {"key": "time", "title": "时间", "width": 95, "type": "mono", "size": 8.5},
            {"key": "task", "title": "巡检任务", "width": 260, "type": "text", "size": 9.2, "color": COLORS["text"]},
            {"key": "result", "title": "结果", "width": 170, "type": "text", "size": 8.8},
            {"key": "status", "title": "状态", "width": 65, "type": "status"},
        ]
        DataTable(b, cols, rows, row_height=38, header_height=28).pack(fill="x", pady=(2, 0))
        foot = ctk.CTkFrame(b, fg_color="transparent")
        foot.pack(fill="x", side="bottom", pady=(10, 0))
        action_button(foot, "关闭", self.destroy, "secondary", None, 72, 32).pack(side="right")
        action_button(foot, "发起单机巡检", lambda: (self.destroy(), self.app.show_page("tasks")), "primary", "play",
                      108, 32).pack(side="right", padx=(0, 8))


def main():
    import ctypes
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        pass
    app = App(capture_mode="--capture" in sys.argv)
    if "--capture" in sys.argv:
        from capture import capture_all
        app.after(1200, lambda: capture_all(app))
    app.mainloop()


if __name__ == "__main__":
    main()

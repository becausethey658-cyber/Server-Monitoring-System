# -*- coding: utf-8 -*-
"""轻量图表渲染：PIL 超采样绘制，界面中保持矢量般的清晰度。"""
from __future__ import annotations

from functools import lru_cache

from PIL import Image, ImageDraw, ImageFont

from theme import COLORS

SCALE = 3
FONT_REG = r"C:\Windows\Fonts\msyh.ttc"
FONT_BOLD = r"C:\Windows\Fonts\msyhbd.ttc"


def _font(size, bold=False):
    try:
        return ImageFont.truetype(FONT_BOLD if bold else FONT_REG, int(size * SCALE))
    except Exception:
        return ImageFont.load_default()


def _text(d, xy, text, size, color, bold=False, anchor="la"):
    d.text((xy[0] * SCALE, xy[1] * SCALE), text, font=_font(size, bold), fill=color, anchor=anchor)


def _line(d, pts, fill, width=2):
    d.line([(x * SCALE, y * SCALE) for x, y in pts], fill=fill, width=int(width * SCALE), joint="curve")


def _dashed(d, p1, p2, fill, width=1.5, dash=7, gap=5):
    import math
    x1, y1 = p1
    x2, y2 = p2
    total = math.hypot(x2 - x1, y2 - y1)
    if total == 0:
        return
    dx, dy = (x2 - x1) / total, (y2 - y1) / total
    t = 0
    while t < total:
        a = (x1 + dx * t, y1 + dy * t)
        b = (x1 + dx * min(t + dash, total), y1 + dy * min(t + dash, total))
        _line(d, [a, b], fill, width)
        t += dash + gap


@lru_cache(maxsize=32)
def donut(score=92.6, healthy=41, attention=5, risk=2, size=150, thickness=17):
    W = size * SCALE
    img = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    pad = thickness * SCALE
    box = [pad, pad, W - pad, W - pad]
    d.ellipse(box, outline="#EEF3F9", width=thickness * SCALE)
    total = healthy + attention + risk
    parts = [(healthy, "#22C55E"), (attention, "#F59E0B"), (risk, "#EF4444")]
    start = -90.0
    gap = 4.0
    for value, color in parts:
        sweep = 360.0 * value / total
        d.arc(box, start=start + gap / 2, end=start + sweep - gap / 2,
              fill=color, width=thickness * SCALE)
        start += sweep
    _text(d, (size / 2, size / 2 - 10), f"{score:.1f}", 25, COLORS["text"], True, "mm")
    _text(d, (size / 2, size / 2 + 17), "综合健康度", 8.2, COLORS["text_muted"], False, "mm")
    return img.resize((size, size), Image.Resampling.LANCZOS)


@lru_cache(maxsize=16)
def progress_ring(percent=68, size=76, color="#2563EB"):
    W = size * SCALE
    img = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    pad = 6 * SCALE
    box = [pad, pad, W - pad, W - pad]
    width = 7 * SCALE
    d.arc(box, start=-90, end=270, fill="#EDF2F8", width=width)
    d.arc(box, start=-90, end=-90 + 360 * percent / 100, fill=color, width=width)
    _text(d, (size / 2, size / 2 - 4), f"{int(percent)}%", 16, COLORS["text"], True, "mm")
    _text(d, (size / 2, size / 2 + 13), "完成度", 7.6, COLORS["text_muted"], False, "mm")
    return img.resize((size, size), Image.Resampling.LANCZOS)


@lru_cache(maxsize=32)
def trend_chart(planned=(), completed=(), labels=(), w=392, h=132):
    W, H = int(w * SCALE), int(h * SCALE)
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    l, r, t, b = 26, 8, 12, 23
    pw, ph = w - l - r, h - t - b
    max_v = max(list(planned) + list(completed) + [16])
    max_v = 20 if max_v <= 20 else 30
    for i in range(4):
        val = max_v * i / 3
        y = t + ph - ph * i / 3
        _line(d, [(l, y), (w - r, y)], "#EEF3F9", 1)
        _text(d, (l - 6, y), f"{int(val)}", 7.5, "#9AA8BA", False, "rm")
    n = len(completed)
    xs = [l + (pw * i / max(1, n - 1)) for i in range(n)]

    def yv(v):
        return t + ph - (v / max_v) * ph

    # 完成面积渐变
    poly = [(xs[i], yv(completed[i])) for i in range(n)] + [(xs[-1], t + ph), (xs[0], t + ph)]
    mask = Image.new("L", (W, H), 0)
    ImageDraw.Draw(mask).polygon([(x * SCALE, y * SCALE) for x, y in poly], fill=255)
    grad = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(grad)
    for yy in range(int(t * SCALE), int((t + ph) * SCALE)):
        ratio = (yy - t * SCALE) / max(1, ph * SCALE)
        alpha = int(50 * (1 - ratio) ** 1.4)
        gd.line([(0, yy), (W, yy)], fill=(37, 99, 235, alpha))
    img.alpha_composite(Image.composite(grad, Image.new("RGBA", (W, H), (0, 0, 0, 0)), mask))

    # 计划虚线
    for i in range(n - 1):
        _dashed(d, (xs[i], yv(planned[i])), (xs[i + 1], yv(planned[i + 1])), "#B9C6D8", 1.4, 6, 4)
    for i in range(n - 1):
        _line(d, [(xs[i], yv(completed[i])), (xs[i + 1], yv(completed[i + 1]))], COLORS["primary"], 2.2)
    for x, v in zip(xs, completed):
        d.ellipse([(x - 2.3) * SCALE, (yv(v) - 2.3) * SCALE, (x + 2.3) * SCALE, (yv(v) + 2.3) * SCALE],
                  fill="#FFFFFF", outline=COLORS["primary"], width=int(1.5 * SCALE))
    for i, lab in enumerate(labels):
        if i == 0 or i == n - 1 or i % 2 == 0:
            _text(d, (xs[i], h - 5), lab, 7.4, "#93A2B5", False, "ms")
    # 图例
    lx = w - 92
    _line(d, [(lx, 6), (lx + 12, 6)], COLORS["primary"], 2)
    _text(d, (lx + 16, 6), "完成", 7.2, "#7D8CA0", False, "lm")
    _dashed(d, (lx + 40, 6), (lx + 52, 6), "#B9C6D8", 1.4, 4, 3)
    _text(d, (lx + 56, 6), "计划", 7.2, "#7D8CA0", False, "lm")
    return img.resize((w, h), Image.Resampling.LANCZOS)


@lru_cache(maxsize=16)
def bar_chart(values=(), labels=(), w=640, h=190, highlight=-1):
    W, H = int(w * SCALE), int(h * SCALE)
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    l, r, t, b = 28, 10, 16, 24
    pw, ph = w - l - r, h - t - b
    max_v = max(values) if values else 10
    max_v = int((max_v // 5 + 1) * 5)
    for i in range(4):
        y = t + ph - ph * i / 3
        _line(d, [(l, y), (w - r, y)], "#EEF3F9", 1)
        _text(d, (l - 6, y), str(int(max_v * i / 3)), 7.5, "#9AA8BA", False, "rm")
    n = len(values)
    slot = pw / n
    bw = min(18, slot * 0.46)
    for i, v in enumerate(values):
        x = l + slot * i + slot / 2
        bh = ph * v / max_v
        color = COLORS["primary"] if i == highlight or (highlight < 0 and i == n - 1) else "#BFD3F6"
        d.rounded_rectangle([(x - bw / 2) * SCALE, (t + ph - bh) * SCALE, (x + bw / 2) * SCALE,
                             (t + ph) * SCALE], radius=int(3 * SCALE), fill=color)
        if i == n - 1:
            _text(d, (x, t + ph - bh - 7), str(v), 7.5, COLORS["primary"], True, "ma")
    for i, lab in enumerate(labels):
        if i % 2 == 0 or i == n - 1:
            x = l + slot * i + slot / 2
            _text(d, (x, h - 5), lab, 7.2, "#93A2B5", False, "ms")
    return img.resize((w, h), Image.Resampling.LANCZOS)


@lru_cache(maxsize=12)
def sparkline(values=(), w=104, h=34, color="#16A34A"):
    W, H = w * SCALE, h * SCALE
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    mn, mx = min(values), max(values)
    rng = max(1, mx - mn)
    pts = [(4 + (w - 8) * i / (len(values) - 1), h - 4 - (v - mn) / rng * (h - 9))
           for i, v in enumerate(values)]
    _line(d, pts, color, 1.7)
    return img.resize((w, h), Image.Resampling.LANCZOS)


def save(img, path):
    img.save(path, "PNG")

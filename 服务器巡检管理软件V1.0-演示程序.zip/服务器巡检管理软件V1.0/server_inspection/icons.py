# -*- coding: utf-8 -*-
"""以 PIL 绘制轻量线性图标，保证界面不依赖外部图标字体。"""
from __future__ import annotations

from functools import lru_cache

import customtkinter as ctk
from PIL import Image, ImageDraw

BASE = 24.0
S = 4


def _draw(size=24, color="#5B6B80", name="monitor", stroke=1.8):
    px = int(size * S)
    img = Image.new("RGBA", (px, px), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)

    def p(v):
        return v * S

    def box(x1, y1, x2, y2):
        return [p(x1), p(y1), p(x2), p(y2)]

    w = max(1, int(stroke * S))
    ink = color

    if name == "dashboard":
        for x, y, fill in [(3, 3, True), (13, 3, False), (3, 13, False), (13, 13, True)]:
            d.rounded_rectangle(box(x, y, x + 8, y + 8), radius=p(2), fill=ink if fill else None,
                                outline=ink, width=w)
    elif name == "server":
        for y in (4, 13):
            d.rounded_rectangle(box(3, y, 21, y + 6), radius=p(1.8), outline=ink, width=w)
            d.ellipse(box(6, y + 2, 7.6, y + 3.6), fill=ink)
            d.line([p(10), p(y + 3), p(18), p(y + 3)], fill=ink, width=w)
    elif name == "template":
        d.rounded_rectangle(box(5, 4, 19, 21), radius=p(2), outline=ink, width=w)
        d.rounded_rectangle(box(8, 2, 16, 6), radius=p(1.2), fill="#FFFFFF", outline=ink, width=w)
        for y in (10, 14, 18):
            d.line([p(8.5), p(y), p(15.5), p(y)], fill=ink, width=w)
    elif name == "plan":
        d.rounded_rectangle(box(3.5, 5, 20.5, 21), radius=p(2), outline=ink, width=w)
        d.line([p(3.5), p(9.5), p(20.5), p(9.5)], fill=ink, width=w)
        d.line([p(8), p(2.8), p(8), p(6.8)], fill=ink, width=w)
        d.line([p(16), p(2.8), p(16), p(6.8)], fill=ink, width=w)
        for x, y in [(7, 13), (12, 13), (17, 13), (7, 17.5), (12, 17.5)]:
            d.ellipse(box(x - 1, y - 1, x + 1, y + 1), fill=ink)
    elif name == "task":
        d.ellipse(box(3, 3, 21, 21), outline=ink, width=w)
        d.line([p(8), p(12.3), p(11), p(15.3), p(16.8), p(8.8)], fill=ink, width=w, joint="curve")
    elif name == "issue":
        d.polygon([p(12), p(2.8), p(21.3), p(20.5), p(2.7), p(20.5)], outline=ink, width=w)
        d.line([p(12), p(8.5), p(12), p(14.2)], fill=ink, width=w)
        d.ellipse(box(11.1, 16.3, 12.9, 18.1), fill=ink)
    elif name == "report":
        d.line([p(4), p(3.5), p(4), p(20.5), p(21), p(20.5)], fill=ink, width=w)
        for x, top in [(7.5, 14), (11.5, 9.5), (15.5, 12), (19.5, 6.5)]:
            d.rounded_rectangle(box(x - 1.2, top, x + 1.2, 18.5), radius=p(1), fill=ink)
    elif name == "settings":
        for y, cx in [(6.5, 15.5), (12, 8.5), (17.5, 13.5)]:
            d.line([p(3.5), p(y), p(20.5), p(y)], fill=ink, width=w)
            d.ellipse(box(cx - 2.2, y - 2.2, cx + 2.2, y + 2.2), fill="#FFFFFF", outline=ink, width=w)
    elif name == "search":
        d.ellipse(box(3.5, 3.5, 16.5, 16.5), outline=ink, width=w)
        d.line([p(15), p(15), p(21), p(21)], fill=ink, width=w)
    elif name == "bell":
        d.pieslice(box(5, 3, 19, 19), start=180, end=360, fill=ink)
        d.rectangle(box(5, 10, 19, 16.5), fill=ink)
        d.polygon([p(3.2), p(17.6), p(20.8), p(17.6), p(18.4), p(15.4), p(5.6), p(15.4)], fill=ink)
        d.ellipse(box(9.8, 18.2, 14.2, 22.0), fill=ink)
        d.rounded_rectangle(box(11.2, 1.8, 12.8, 4.4), radius=p(.8), fill=ink)
    elif name == "plus":
        d.line([p(12), p(4.5), p(12), p(19.5)], fill=ink, width=w)
        d.line([p(4.5), p(12), p(19.5), p(12)], fill=ink, width=w)
    elif name == "minus":
        d.line([p(4.5), p(12), p(19.5), p(12)], fill=ink, width=w)
    elif name == "download":
        d.line([p(12), p(3.5), p(12), p(15.5)], fill=ink, width=w)
        d.line([p(7), p(11), p(12), p(16), p(17), p(11)], fill=ink, width=w, joint="curve")
        d.line([p(4), p(20.5), p(20), p(20.5)], fill=ink, width=w)
    elif name == "refresh":
        d.arc(box(4, 4, 20, 20), start=35, end=150, fill=ink, width=w)
        d.arc(box(4, 4, 20, 20), start=215, end=330, fill=ink, width=w)
        d.polygon([p(18.4), p(3.5), p(20.6), p(8.3), p(15.6), p(8.0)], fill=ink)
        d.polygon([p(5.6), p(20.5), p(3.4), p(15.7), p(8.4), p(16.0)], fill=ink)
    elif name == "arrow_right":
        d.line([p(4), p(12), p(20), p(12)], fill=ink, width=w)
        d.line([p(14), p(6), p(20), p(12), p(14), p(18)], fill=ink, width=w, joint="curve")
    elif name == "chevron_down":
        d.line([p(6), p(9), p(12), p(15), p(18), p(9)], fill=ink, width=w, joint="curve")
    elif name == "close":
        d.line([p(5.5), p(5.5), p(18.5), p(18.5)], fill=ink, width=w)
        d.line([p(18.5), p(5.5), p(5.5), p(18.5)], fill=ink, width=w)
    elif name == "check":
        d.line([p(4.5), p(12.5), p(9.5), p(17.5), p(19.5), p(6.5)], fill=ink, width=w, joint="curve")
    elif name == "clock":
        d.ellipse(box(3, 3, 21, 21), outline=ink, width=w)
        d.line([p(12), p(7), p(12), p(12.5), p(16), p(15)], fill=ink, width=w, joint="curve")
    elif name == "user":
        d.ellipse(box(8, 3.5, 16, 11.5), outline=ink, width=w)
        d.arc(box(3.5, 12.5, 20.5, 25), start=180, end=360, fill=ink, width=w)
    elif name == "shield":
        d.polygon([p(12), p(2.6), p(20.5), p(6), p(20.5), p(12), p(12), p(21.7),
                   p(3.5), p(12), p(3.5), p(6)], outline=ink, width=w)
        d.line([p(8.5), p(12), p(11), p(14.8), p(16), p(9.5)], fill=ink, width=w, joint="curve")
    elif name == "database":
        d.ellipse(box(4, 3, 20, 8), outline=ink, width=w)
        d.line([p(4), p(5.5), p(4), p(18.5)], fill=ink, width=w)
        d.line([p(20), p(5.5), p(20), p(18.5)], fill=ink, width=w)
        d.arc(box(4, 14, 20, 21), start=0, end=180, fill=ink, width=w)
        d.arc(box(4, 9, 20, 15), start=0, end=180, fill=ink, width=w)
    elif name == "mail":
        d.rounded_rectangle(box(3, 5.5, 21, 18.5), radius=p(1.5), outline=ink, width=w)
        d.line([p(4), p(7), p(12), p(13), p(20), p(7)], fill=ink, width=w, joint="curve")
    elif name == "wechat":
        d.ellipse(box(2.5, 4, 14, 14), outline=ink, width=w)
        d.polygon([p(5.5), p(13), p(4), p(17.5), p(8), p(15)], fill=ink)
        d.ellipse(box(10, 9.5, 21, 19.5), fill="#FFFFFF", outline=ink, width=w)
        d.polygon([p(18), p(19), p(20), p(22.2), p(15.8), p(20.2)], fill=ink)
        d.ellipse(box(7, 7, 8.4, 8.4), fill=ink)
        d.ellipse(box(10.5, 7, 11.9, 8.4), fill=ink)
        d.ellipse(box(13, 12.5, 14.4, 13.9), fill=ink)
        d.ellipse(box(16.5, 12.5, 17.9, 13.9), fill=ink)
    elif name == "webhook":
        d.ellipse(box(8.7, 3, 15.3, 9.6), outline=ink, width=w)
        d.ellipse(box(2.8, 13, 9.4, 19.6), outline=ink, width=w)
        d.ellipse(box(14.6, 13, 21.2, 19.6), outline=ink, width=w)
        d.line([p(11), p(9), p(6.5), p(14.5)], fill=ink, width=w)
        d.line([p(13), p(9.2), p(17.5), p(14.5)], fill=ink, width=w)
        d.line([p(6.2), p(17), p(17.8), p(17)], fill=ink, width=w)
    elif name == "play":
        d.polygon([p(7.5), p(4.5), p(19.5), p(12), p(7.5), p(19.5)], outline=ink, width=w)
    elif name == "pause":
        d.rounded_rectangle(box(7, 5, 10, 19), radius=p(1), fill=ink)
        d.rounded_rectangle(box(14, 5, 17, 19), radius=p(1), fill=ink)
    elif name == "edit":
        d.polygon([p(4), p(16.5), p(15.5), p(5), p(19), p(8.5), p(7.5), p(20), p(4), p(20)], outline=ink, width=w)
        d.line([p(13.5), p(7), p(17), p(10.5)], fill=ink, width=w)
    elif name == "copy":
        d.rounded_rectangle(box(8, 3, 20, 15), radius=p(2), outline=ink, width=w)
        d.rounded_rectangle(box(4, 7, 16, 21), radius=p(2), fill="#FFFFFF", outline=ink, width=w)
    elif name == "filter":
        d.polygon([p(3.5), p(4.5), p(20.5), p(4.5), p(14), p(12), p(14), p(19), p(10), p(21),
                   p(10), p(12)], outline=ink, width=w)
    elif name == "calendar":
        d.rounded_rectangle(box(3.5, 5, 20.5, 21), radius=p(2), outline=ink, width=w)
        d.line([p(3.5), p(9.5), p(20.5), p(9.5)], fill=ink, width=w)
        d.line([p(8), p(2.8), p(8), p(6.8)], fill=ink, width=w)
        d.line([p(16), p(2.8), p(16), p(6.8)], fill=ink, width=w)
    elif name == "cpu":
        d.rounded_rectangle(box(7, 7, 17, 17), radius=p(1.5), outline=ink, width=w)
        d.rounded_rectangle(box(10, 10, 14, 14), radius=p(.8), outline=ink, width=w)
        for v in (8, 12, 16):
            d.line([p(v), p(3), p(v), p(6.5)], fill=ink, width=w)
            d.line([p(v), p(17.5), p(v), p(21)], fill=ink, width=w)
            d.line([p(3), p(v), p(6.5), p(v)], fill=ink, width=w)
            d.line([p(17.5), p(v), p(21), p(v)], fill=ink, width=w)
    elif name == "memory":
        d.rounded_rectangle(box(3, 7, 21, 17), radius=p(1.5), outline=ink, width=w)
        for x in (6.5, 10, 13.5, 17):
            d.line([p(x), p(10), p(x), p(14)], fill=ink, width=w)
        d.line([p(6), p(19), p(6), p(21.5)], fill=ink, width=w)
        d.line([p(18), p(19), p(18), p(21.5)], fill=ink, width=w)
    elif name == "disk":
        d.ellipse(box(4, 3, 20, 8), outline=ink, width=w)
        d.line([p(4), p(5.5), p(4), p(18.5)], fill=ink, width=w)
        d.line([p(20), p(5.5), p(20), p(18.5)], fill=ink, width=w)
        d.arc(box(4, 14, 20, 21), start=0, end=180, fill=ink, width=w)
    elif name == "activity":
        d.line([p(2.5), p(12), p(7), p(12), p(9.5), p(5.5), p(13.5), p(18.5), p(16.3), p(12),
                p(21.5), p(12)], fill=ink, width=w, joint="curve")
    elif name == "back":
        d.line([p(19), p(12), p(5), p(12)], fill=ink, width=w)
        d.line([p(11), p(6), p(5), p(12), p(11), p(18)], fill=ink, width=w, joint="curve")
    elif name == "external":
        d.polyline([p(13), p(4.5), p(20), p(4.5), p(20), p(11.5)], fill=ink, width=w)
        d.line([p(20), p(4.5), p(11), p(13.5)], fill=ink, width=w)
        d.polyline([p(18), p(14), p(18), p(20), p(4), p(20), p(4), p(6), p(10), p(6)],
                   fill=ink, width=w)
    elif name == "file":
        d.polygon([p(5), p(2.5), p(14), p(2.5), p(19), p(7.5), p(19), p(21.5), p(5), p(21.5)],
                  outline=ink, width=w)
        d.line([p(14), p(3), p(14), p(8), p(19), p(8)], fill=ink, width=w)
        d.line([p(8), p(12), p(16), p(12)], fill=ink, width=w)
        d.line([p(8), p(16), p(16), p(16)], fill=ink, width=w)
    elif name == "lock":
        d.rounded_rectangle(box(4.5, 10, 19.5, 21), radius=p(2), outline=ink, width=w)
        d.arc(box(7.5, 3.5, 16.5, 13), start=180, end=360, fill=ink, width=w)
        d.ellipse(box(11, 14.5, 13, 16.5), fill=ink)
        d.line([p(12), p(16), p(12), p(18.5)], fill=ink, width=w)
    elif name == "spark":
        d.line([p(12), p(2.5), p(12), p(8.5)], fill=ink, width=w)
        d.line([p(12), p(15.5), p(12), p(21.5)], fill=ink, width=w)
        d.line([p(2.5), p(12), p(8.5), p(12)], fill=ink, width=w)
        d.line([p(15.5), p(12), p(21.5), p(12)], fill=ink, width=w)
        d.line([p(5.3), p(5.3), p(9.5), p(9.5)], fill=ink, width=w)
        d.line([p(14.5), p(14.5), p(18.7), p(18.7)], fill=ink, width=w)
        d.line([p(18.7), p(5.3), p(14.5), p(9.5)], fill=ink, width=w)
        d.line([p(5.3), p(18.7), p(9.5), p(14.5)], fill=ink, width=w)
    elif name == "monitor":
        d.rounded_rectangle(box(2.5, 4, 21.5, 17), radius=p(1.8), outline=ink, width=w)
        d.line([p(8), p(21), p(16), p(21)], fill=ink, width=w)
        d.line([p(12), p(17), p(12), p(21)], fill=ink, width=w)
    elif name == "dots":
        for x in (6, 12, 18):
            d.ellipse(box(x - 1.5, 10.5, x + 1.5, 13.5), fill=ink)
    elif name == "logo":
        img = Image.new("RGBA", (96, 96), (0, 0, 0, 0))
        d = ImageDraw.Draw(img)
        d.rounded_rectangle([0, 0, 95, 95], radius=24, fill="#2563EB")
        d.rounded_rectangle([21, 23, 75, 40], radius=5, outline="#FFFFFF", width=5)
        d.rounded_rectangle([21, 47, 75, 64], radius=5, outline="#FFFFFF", width=5)
        d.ellipse([28, 29, 34, 35], fill="#FFFFFF")
        d.ellipse([28, 53, 34, 59], fill="#FFFFFF")
        d.line([40, 32, 66, 32], fill="#FFFFFF", width=4)
        d.line([40, 56, 66, 56], fill="#FFFFFF", width=4)
        d.ellipse([50, 58, 86, 94], fill="#0E1B2C", outline="#FFFFFF", width=4)
        d.line([59, 77, 66, 84, 77, 69], fill="#34D399", width=5, joint="curve")
        return img
    else:
        d.ellipse(box(4, 4, 20, 20), outline=ink, width=w)

    return img.resize((int(size), int(size)), Image.Resampling.LANCZOS)


@lru_cache(maxsize=256)
def _icon_cached(name, color, size):
    return _draw(size=size, color=color, name=name)


_ICON_REFS = []
LOGO = None


def icon(name, color="#5B6B80", size=20):
    img = _icon_cached(name, color, size)
    ci = ctk.CTkImage(light_image=img, dark_image=img, size=(size, size))
    _ICON_REFS.append(ci)
    return ci


def logo_image(size=38):
    global LOGO
    if LOGO is None:
        raw = _draw(size=96, name="logo")
        LOGO = ctk.CTkImage(light_image=raw, dark_image=raw, size=(size, size))
    return LOGO

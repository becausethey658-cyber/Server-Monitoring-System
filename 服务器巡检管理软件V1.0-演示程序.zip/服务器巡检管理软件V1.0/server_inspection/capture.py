# -*- coding: utf-8 -*-
"""自动截图脚本：在真实窗口中逐页渲染并截取客户区。"""
from __future__ import annotations

import ctypes
import os
import time

from PIL import ImageGrab

from data import ISSUES, TASKS

OUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "screenshots", "raw")


def _grab(app, name):
    app.update_idletasks()
    app.update()
    time.sleep(0.55)
    app.lift()
    app.attributes("-topmost", True)
    app.update_idletasks()
    x, y = app.winfo_rootx(), app.winfo_rooty()
    w, h = app.winfo_width(), app.winfo_height()
    im = ImageGrab.grab(bbox=(x, y, x + w, y + h), all_screens=True)
    os.makedirs(OUT_DIR, exist_ok=True)
    path = os.path.join(OUT_DIR, name + ".png")
    im.save(path, "PNG")
    print("captured", path, im.size, flush=True)


def capture_all(app):
    # 截图期间保持显示器唤醒，避免锁屏导致黑屏。
    try:
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000003)
    except Exception:
        pass
    os.makedirs(OUT_DIR, exist_ok=True)
    order = [
        ("01_dashboard", "dashboard", None),
        ("02_servers", "servers", None),
        ("03_templates", "templates", None),
        ("04_plans", "plans", None),
        ("05_tasks", "tasks", None),
        ("06_issues", "issues", None),
        ("07_reports", "reports", None),
        ("08_settings", "settings", None),
    ]
    idx = 0

    def nxt():
        nonlocal idx
        if idx < len(order):
            name, page, _ = order[idx]
            app.show_page(page)
            app.after(650, lambda n=name: _after_show(n))
            idx += 1
        elif idx == len(order):
            app.show_task_detail(TASKS[0])
            app.after(900, lambda: _after_detail("09_task_detail"))
            idx += 1
        elif idx == len(order) + 1:
            app.show_issue_detail(ISSUES[0])
            app.after(900, lambda: _after_detail("10_issue_detail"))
            idx += 1
        else:
            app.after(400, app.destroy)

    def _after_show(name):
        _grab(app, name)
        app.after(250, nxt)

    def _after_detail(name):
        _grab(app, name)
        app.after(250, nxt)

    app.after(500, nxt)

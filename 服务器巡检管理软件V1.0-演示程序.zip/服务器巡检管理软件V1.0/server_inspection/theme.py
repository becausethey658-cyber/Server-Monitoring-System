# -*- coding: utf-8 -*-
"""视觉规范与基础样式。"""

FONT_FAMILY = "Microsoft YaHei UI"
MONO_FAMILY = "Consolas"

COLORS = {
    "bg": "#F3F6FA",
    "surface": "#FFFFFF",
    "surface_alt": "#F8FAFC",
    "sidebar": "#0E1B2C",
    "sidebar_alt": "#15253A",
    "sidebar_text": "#93A4B8",
    "sidebar_active": "#2563EB",
    "text": "#162033",
    "text_secondary": "#5B6B80",
    "text_muted": "#8A99AC",
    "border": "#E4EAF2",
    "border_strong": "#D4DEEA",
    "primary": "#2563EB",
    "primary_hover": "#1D4ED8",
    "primary_soft": "#EAF1FF",
    "success": "#16A34A",
    "success_soft": "#E9F8EF",
    "warning": "#D97706",
    "warning_soft": "#FFF5E5",
    "danger": "#DC2626",
    "danger_soft": "#FDECEC",
    "info": "#0891B2",
    "info_soft": "#E7F8FB",
    "violet": "#7C3AED",
    "violet_soft": "#F1EBFF",
    "track": "#EDF2F8",
}

# 语义色：级别、状态
LEVEL_COLORS = {
    "严重": ("#DC2626", "#FDECEC"),
    "高危": ("#D97706", "#FFF5E5"),
    "中": ("#2563EB", "#EAF1FF"),
    "低": ("#64748B", "#F1F5F9"),
    "提示": ("#0891B2", "#E7F8FB"),
}

STATUS_COLORS = {
    "在线": ("#16A34A", "#E9F8EF"),
    "已离线": ("#64748B", "#F1F5F9"),
    "离线": ("#64748B", "#F1F5F9"),
    "执行中": ("#2563EB", "#EAF1FF"),
    "已完成": ("#16A34A", "#E9F8EF"),
    "失败": ("#DC2626", "#FDECEC"),
    "排队中": ("#D97706", "#FFF5E5"),
    "待处理": ("#DC2626", "#FDECEC"),
    "处理中": ("#D97706", "#FFF5E5"),
    "已指派": ("#2563EB", "#EAF1FF"),
    "已闭环": ("#16A34A", "#E9F8EF"),
    "启用": ("#16A34A", "#E9F8EF"),
    "停用": ("#64748B", "#F1F5F9"),
    "正常": ("#16A34A", "#E9F8EF"),
    "需关注": ("#D97706", "#FFF5E5"),
    "风险": ("#DC2626", "#FDECEC"),
}


def F(size=12, weight="normal"):
    return (FONT_FAMILY, size, weight)


def mono(size=11):
    return (MONO_FAMILY, size)


def level_palette(level):
    return LEVEL_COLORS.get(level, ("#64748B", "#F1F5F9"))


def status_palette(status):
    return STATUS_COLORS.get(status, ("#64748B", "#F1F5F9"))


def health_color(score):
    if score >= 90:
        return COLORS["success"]
    if score >= 80:
        return "#65A30D"
    if score >= 70:
        return COLORS["warning"]
    return COLORS["danger"]

@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo 正在启动 服务器巡检管理软件 V1.0 ...
python run.py
if errorlevel 1 (
  echo.
  echo 启动失败：请确认已安装 Python 3.10 及以上版本，并在安装时勾选 Add Python to PATH。
  pause
)
